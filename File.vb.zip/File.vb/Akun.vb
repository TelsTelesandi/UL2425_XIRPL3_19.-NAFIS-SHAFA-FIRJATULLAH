﻿
Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Text
Public Class Akun
    ' Connection string - sesuaikan dengan database Anda
    Private connectionString As String = "Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True"
    Private currentUserId As Integer = 0 ' Untuk tracking user yang sedang diedit

    Private Sub Akun_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeComboBoxes()
        LoadUserData()
        ClearForm()
    End Sub
    Private Sub InitializeComboBoxes()
        ' ComboBox Role
        cmbRole.Items.Clear()
        cmbRole.Items.Add("admin")
        cmbRole.Items.Add("user")
        cmbRole.DropDownStyle = ComboBoxStyle.DropDownList

        ' ComboBox Jenis Pengguna
        cmbJenisPengguna.Items.Clear()
        cmbJenisPengguna.Items.Add("guru")
        cmbJenisPengguna.Items.Add("siswa")
        cmbJenisPengguna.DropDownStyle = ComboBoxStyle.DropDownList
    End Sub
    Private Sub LoadUserData()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String = "SELECT user_id, id_card, username, role, jenis_pengguna, nama_lengkap FROM Users ORDER BY user_id"
                Dim adapter As New SqlDataAdapter(query, connection)
                Dim dataTable As New DataTable()
                adapter.Fill(dataTable)

                DataGridView1.DataSource = dataTable
                DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

                ' Rename column headers untuk tampilan yang lebih baik
                If DataGridView1.Columns.Count > 0 Then
                    DataGridView1.Columns("user_id").HeaderText = "ID"
                    DataGridView1.Columns("id_card").HeaderText = "ID Card"
                    DataGridView1.Columns("username").HeaderText = "Username"
                    DataGridView1.Columns("role").HeaderText = "Role"
                    DataGridView1.Columns("jenis_pengguna").HeaderText = "Jenis Pengguna"
                    DataGridView1.Columns("nama_lengkap").HeaderText = "Nama Lengkap"
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Function HashPassword(password As String) As String
        Using sha256Hash As SHA256 = SHA256.Create()
            Dim bytes As Byte() = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password))
            Dim builder As New StringBuilder()
            For i As Integer = 0 To bytes.Length - 1
                builder.Append(bytes(i).ToString("x2"))
            Next
            Return builder.ToString().ToUpper()
        End Using
    End Function
    Private Function ValidateInput() As Boolean
        If String.IsNullOrWhiteSpace(txtIDCard.Text) Then
            MessageBox.Show("ID Card harus diisi!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtIDCard.Focus()
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtUsername.Text) Then
            MessageBox.Show("Username harus diisi!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtUsername.Focus()
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtPassword.Text) AndAlso currentUserId = 0 Then
            MessageBox.Show("Password harus diisi untuk user baru!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPassword.Focus()
            Return False
        End If

        If cmbRole.SelectedIndex = -1 Then
            MessageBox.Show("Role harus dipilih!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbRole.Focus()
            Return False
        End If

        If cmbJenisPengguna.SelectedIndex = -1 Then
            MessageBox.Show("Jenis Pengguna harus dipilih!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbJenisPengguna.Focus()
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtNamaLengkap.Text) Then
            MessageBox.Show("Nama Lengkap harus diisi!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNamaLengkap.Focus()
            Return False
        End If

        Return True
    End Function
    Private Function IsUsernameExists(username As String, Optional excludeUserId As Integer = 0) As Boolean
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM Users WHERE username = @username"
                If excludeUserId > 0 Then
                    query += " AND user_id != @userId"
                End If

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@username", username)
                    If excludeUserId > 0 Then
                        command.Parameters.AddWithValue("@userId", excludeUserId)
                    End If

                    Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error checking username: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return True ' Return true untuk mencegah duplikasi jika terjadi error
        End Try
    End Function

    ' Cek apakah ID Card sudah ada
    Private Function IsIdCardExists(idCard As String, Optional excludeUserId As Integer = 0) As Boolean
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM Users WHERE id_card = @id_card"
                If excludeUserId > 0 Then
                    query += " AND user_id != @userId"
                End If

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@id_card", idCard)
                    If excludeUserId > 0 Then
                        command.Parameters.AddWithValue("@userId", excludeUserId)
                    End If

                    Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error checking ID Card: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return True ' Return true untuk mencegah duplikasi jika terjadi error
        End Try
    End Function

    Private Sub btnsimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        If Not ValidateInput() Then Exit Sub

        ' Cek ID Card duplikat
        If IsIdCardExists(txtIDCard.Text.Trim(), currentUserId) Then
            MessageBox.Show("ID Card sudah digunakan!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtIDCard.Focus()
            Exit Sub
        End If

        ' Cek username duplikat
        If IsUsernameExists(txtUsername.Text.Trim(), currentUserId) Then
            MessageBox.Show("Username sudah digunakan!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtUsername.Focus()
            Exit Sub
        End If

        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String

                If currentUserId = 0 Then
                    ' INSERT - User baru
                    query = "INSERT INTO Users (id_card, username, password, role, jenis_pengguna, nama_lengkap) " &
                           "VALUES (@id_card, @username, @password, @role, @jenis_pengguna, @nama_lengkap)"
                Else
                    ' UPDATE - User existing
                    If String.IsNullOrWhiteSpace(txtPassword.Text) Then
                        ' Update tanpa password
                        query = "UPDATE Users SET id_card = @id_card, username = @username, " &
                               "role = @role, jenis_pengguna = @jenis_pengguna, nama_lengkap = @nama_lengkap " &
                               "WHERE user_id = @user_id"
                    Else
                        ' Update dengan password
                        query = "UPDATE Users SET id_card = @id_card, username = @username, password = @password, " &
                               "role = @role, jenis_pengguna = @jenis_pengguna, nama_lengkap = @nama_lengkap " &
                               "WHERE user_id = @user_id"
                    End If
                End If

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@id_card", txtIDCard.Text.Trim())
                    command.Parameters.AddWithValue("@username", txtUsername.Text.Trim())
                    command.Parameters.AddWithValue("@role", cmbRole.SelectedItem.ToString())
                    command.Parameters.AddWithValue("@jenis_pengguna", cmbJenisPengguna.SelectedItem.ToString())
                    command.Parameters.AddWithValue("@nama_lengkap", txtNamaLengkap.Text.Trim())

                    ' Tambahkan parameter password jika diperlukan
                    If Not String.IsNullOrWhiteSpace(txtPassword.Text) Then
                        command.Parameters.AddWithValue("@password", HashPassword(txtPassword.Text))
                    End If

                    ' Tambahkan parameter user_id untuk UPDATE
                    If currentUserId > 0 Then
                        command.Parameters.AddWithValue("@user_id", currentUserId)
                    End If

                    Dim rowsAffected As Integer = command.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Data berhasil disimpan!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        LoadUserData()
                        ClearForm()
                    Else
                        MessageBox.Show("Gagal menyimpan data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error saving data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnedit_Click(sender As Object, e As EventArgs) Handles btnedit.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Pilih user yang akan diedit!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Try
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
            currentUserId = Convert.ToInt32(selectedRow.Cells("user_id").Value)

            txtIDCard.Text = selectedRow.Cells("id_card").Value.ToString()
            txtUsername.Text = selectedRow.Cells("username").Value.ToString()
            txtPassword.Text = "" ' Kosongkan password untuk keamanan
            cmbRole.SelectedItem = selectedRow.Cells("role").Value.ToString()
            cmbJenisPengguna.SelectedItem = selectedRow.Cells("jenis_pengguna").Value.ToString()
            txtNamaLengkap.Text = selectedRow.Cells("nama_lengkap").Value.ToString()

            MessageBox.Show("Data user telah dimuat untuk diedit. Kosongkan password jika tidak ingin mengubahnya.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error loading user data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnhapus_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Pilih user yang akan dihapus!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
        Dim username As String = selectedRow.Cells("username").Value.ToString()

        Dim result As DialogResult = MessageBox.Show($"Apakah Anda yakin ingin menghapus user '{username}'?", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Try
                Using connection As New SqlConnection(connectionString)
                    connection.Open()
                    Dim query As String = "DELETE FROM Users WHERE user_id = @user_id"

                    Using command As New SqlCommand(query, connection)
                        command.Parameters.AddWithValue("@user_id", Convert.ToInt32(selectedRow.Cells("user_id").Value))

                        Dim rowsAffected As Integer = command.ExecuteNonQuery()

                        If rowsAffected > 0 Then
                            MessageBox.Show("User berhasil dihapus!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            LoadUserData()
                            ClearForm()
                        Else
                            MessageBox.Show("Gagal menghapus user!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error deleting user: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        ClearForm()
    End Sub

    ' Bersihkan form
    Private Sub ClearForm()
        currentUserId = 0
        txtIDCard.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        cmbRole.SelectedIndex = -1
        cmbJenisPengguna.SelectedIndex = -1
        txtNamaLengkap.Clear()
        txtIDCard.Focus()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        ' Optional: Auto select row ketika di-klik
        If e.RowIndex >= 0 Then
            DataGridView1.Rows(e.RowIndex).Selected = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        DashboardAdmin.Show()
    End Sub
End Class
﻿Imports System.Data.SqlClient
Imports System.IO

Public Class StatusAdmin
    ' Add class-level variables for pagination
    Private printRowIndex As Integer = 0
    Private printTotalRows As Integer = 0
    Private printDataTable As DataTable = Nothing

    Private Sub cmbFilterStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFilterStatus.SelectedIndexChanged
        Try
            If cmbFilterStatus.SelectedItem IsNot Nothing Then
                Dim selectedStatus As String = cmbFilterStatus.SelectedItem.ToString()
                FilterByStatus(selectedStatus)
            End If
        Catch ex As Exception
            MessageBox.Show("Error applying filter: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub btnprint_Click(sender As Object, e As EventArgs) Handles btnprint.Click
        Try
            ' Check if there's data to print
            If DataGridView1.Rows.Count = 0 Then
                MessageBox.Show("Tidak ada data untuk dicetak!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Initialize pagination variables
            printRowIndex = 0
            printTotalRows = DataGridView1.Rows.Count
            printDataTable = CType(DataGridView1.DataSource, DataTable)

            ' Set print document to landscape orientation
            PrintDocument1.DefaultPageSettings.Landscape = True

            ' Show print preview dialog
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()

        Catch ex As Exception
            MessageBox.Show("Error saat mempersiapkan dokumen cetak: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        ' Reset filter to "Semua"
        cmbFilterStatus.SelectedIndex = 0
        LoadAllDataPeminjaman()
    End Sub

    Private Sub btnkembali_Click(sender As Object, e As EventArgs) Handles btnkembali.Click
        Me.Close()
        DashboardAdmin.Show()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Try
            ' Set fonts and brushes
            Dim titleFont As New Font("Arial", 18, FontStyle.Bold)
            Dim subtitleFont As New Font("Arial", 14, FontStyle.Regular)
            Dim headerFont As New Font("Arial", 11, FontStyle.Bold)
            Dim normalFont As New Font("Arial", 9, FontStyle.Regular)
            Dim smallFont As New Font("Arial", 8, FontStyle.Regular)
            Dim blackBrush As New SolidBrush(Color.Black)

            ' Set initial position and margins for landscape
            Dim yPosition As Integer = 50
            Dim leftMargin As Integer = 50
            Dim rightMargin As Integer = e.PageBounds.Width - 50
            Dim pageWidth As Integer = e.PageBounds.Width - 100
            Dim pageHeight As Integer = e.PageBounds.Height

            ' Calculate if this is the first page
            Dim isFirstPage As Boolean = (printRowIndex = 0)

            ' === HEADER SECTION (Only on first page) ===
            If isFirstPage Then
                ' Draw logo from resources
                Dim logoWidth As Integer = 60
                Dim logoHeight As Integer = 60

                Try
                    ' Get logo from project resources
                    Dim logo As Image = My.Resources.ChatGPT_Image_23_Mei_2025__08_46_38
                    If logo IsNot Nothing Then
                        e.Graphics.DrawImage(logo, leftMargin, yPosition, logoWidth, logoHeight)
                    Else
                        ' Draw placeholder if resource not found
                        e.Graphics.DrawRectangle(Pens.Black, leftMargin, yPosition, logoWidth, logoHeight)
                        e.Graphics.DrawString("LOGO", normalFont, blackBrush, leftMargin + 15, yPosition + 25)
                    End If
                Catch logoEx As Exception
                    ' If logo fails to load, draw a placeholder rectangle
                    e.Graphics.DrawRectangle(Pens.Black, leftMargin, yPosition, logoWidth, logoHeight)
                    e.Graphics.DrawString("LOGO", normalFont, blackBrush, leftMargin + 15, yPosition + 25)
                End Try

                ' Draw title next to logo
                Dim titleX As Integer = leftMargin + logoWidth + 20
                e.Graphics.DrawString("SISTEM PEMINJAMAN RUANGAN", titleFont, blackBrush, titleX, yPosition + 5)
                e.Graphics.DrawString("REKAP STATUS PEMINJAMAN DAN PENGEMBALIAN", subtitleFont, blackBrush, titleX, yPosition + 30)

                yPosition += logoHeight + 20

                ' Draw horizontal line separator
                e.Graphics.DrawLine(Pens.Black, leftMargin, yPosition, rightMargin, yPosition)
                yPosition += 15

                ' Get current filter status for report header
                Dim currentFilter As String = If(cmbFilterStatus.SelectedItem IsNot Nothing, cmbFilterStatus.SelectedItem.ToString(), "Semua")
                e.Graphics.DrawString($"Filter Status: {currentFilter}", headerFont, blackBrush, leftMargin, yPosition)
                yPosition += 20

                e.Graphics.DrawString($"Total Data: {printTotalRows} record", normalFont, blackBrush, leftMargin, yPosition)
                yPosition += 25
            Else
                ' For continuation pages, add a simple header
                e.Graphics.DrawString("REKAP STATUS PEMINJAMAN DAN PENGEMBALIAN (Lanjutan)", subtitleFont, blackBrush, leftMargin, yPosition)
                yPosition += 30
            End If

            ' === DATA SECTION ===
            ' Adjust column widths for landscape orientation
            Dim colWidths() As Integer = {60, 85, 120, 120, 85, 70, 80, 100, 100} ' Adjusted widths for landscape
            Dim headerY As Integer = yPosition

            ' Table headers
            Dim headerTexts() As String = {"ID", "Tanggal", "Ruangan", "Peminjam", "Waktu", "Durasi", "Status", "Keterangan", "Lokasi"}
            Dim currentX As Integer = leftMargin

            For i As Integer = 0 To headerTexts.Length - 1
                e.Graphics.DrawString(headerTexts(i), headerFont, blackBrush, currentX, headerY)
                currentX += colWidths(i)
            Next

            yPosition += 25

            ' Draw line under headers
            e.Graphics.DrawLine(Pens.Black, leftMargin, yPosition, rightMargin, yPosition)
            yPosition += 10

            ' Calculate maximum rows that can fit on current page
            Dim availableHeight As Integer = pageHeight - yPosition - 200 ' Reserve more space for footer and signatures
            Dim rowHeight As Integer = 18
            Dim maxRowsThisPage As Integer = availableHeight \ rowHeight

            ' Draw data rows
            Dim rowsPrintedThisPage As Integer = 0
            Dim totalRowsPrinted As Integer = printRowIndex

            For i As Integer = printRowIndex To printTotalRows - 1
                If rowsPrintedThisPage >= maxRowsThisPage Then
                    Exit For ' Stop if we've reached the page limit
                End If

                Dim row As DataGridViewRow = DataGridView1.Rows(i)

                If row.Cells("peminjaman_id").Value IsNot Nothing AndAlso Not IsDBNull(row.Cells("peminjaman_id").Value) Then
                    currentX = leftMargin

                    ' Draw row data
                    e.Graphics.DrawString(SafeToString(row.Cells("peminjaman_id").Value), normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(0)

                    ' Format date
                    Dim tanggal As String = ""
                    If row.Cells("tanggal").Value IsNot Nothing AndAlso Not IsDBNull(row.Cells("tanggal").Value) Then
                        Try
                            Dim dateValue As DateTime
                            If DateTime.TryParse(row.Cells("tanggal").Value.ToString(), dateValue) Then
                                tanggal = dateValue.ToString("dd/MM/yyyy")
                            Else
                                tanggal = row.Cells("tanggal").Value.ToString()
                            End If
                        Catch ex As Exception
                            tanggal = "Invalid Date"
                        End Try
                    End If
                    e.Graphics.DrawString(tanggal, normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(1)

                    e.Graphics.DrawString(TruncateString(SafeToString(row.Cells("nama_ruangan").Value), 16), normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(2)

                    e.Graphics.DrawString(TruncateString(SafeToString(row.Cells("nama_lengkap").Value), 16), normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(3)

                    e.Graphics.DrawString(SafeToString(row.Cells("waktu_mulai").Value), normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(4)

                    e.Graphics.DrawString(SafeToString(row.Cells("durasi_peminjaman").Value), normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(5)

                    e.Graphics.DrawString(SafeToString(row.Cells("status").Value), normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(6)

                    e.Graphics.DrawString(TruncateString(SafeToString(row.Cells("keterangan").Value), 12), normalFont, blackBrush, currentX, yPosition)
                    currentX += colWidths(7)

                    e.Graphics.DrawString(TruncateString(SafeToString(row.Cells("lokasi").Value), 12), normalFont, blackBrush, currentX, yPosition)

                    yPosition += rowHeight
                    rowsPrintedThisPage += 1
                    totalRowsPrinted += 1
                End If
            Next

            ' Update printRowIndex for next page
            printRowIndex += rowsPrintedThisPage

            ' === FOOTER SECTION (Only on last page) ===
            Dim isLastPage As Boolean = (printRowIndex >= printTotalRows)

            If isLastPage Then
                ' Position signature section higher to avoid overlapping with timestamp
                Dim signatureStartY As Integer = pageHeight - 180

                ' Draw line above signature section
                e.Graphics.DrawLine(Pens.Black, leftMargin, signatureStartY, rightMargin, signatureStartY)
                signatureStartY += 20

                ' Signature sections
                Dim signatureWidth As Integer = 200
                Dim leftSignatureX As Integer = leftMargin + 100
                Dim rightSignatureX As Integer = rightMargin - signatureWidth - 100

                ' Left signature (Admin)
                e.Graphics.DrawString("Mengetahui,", normalFont, blackBrush, leftSignatureX, signatureStartY)
                e.Graphics.DrawString("Administrator", normalFont, blackBrush, leftSignatureX, signatureStartY + 20)

                ' Signature line for admin
                e.Graphics.DrawLine(Pens.Black, leftSignatureX, signatureStartY + 70, leftSignatureX + signatureWidth, signatureStartY + 70)
                e.Graphics.DrawString("(.............................)", normalFont, blackBrush, leftSignatureX + 50, signatureStartY + 80)

                ' Right signature
                e.Graphics.DrawString("Menyetujui,", normalFont, blackBrush, rightSignatureX, signatureStartY)
                e.Graphics.DrawString("Kepala Bagian", normalFont, blackBrush, rightSignatureX, signatureStartY + 20)

                ' Signature line for approver
                e.Graphics.DrawLine(Pens.Black, rightSignatureX, signatureStartY + 70, rightSignatureX + signatureWidth, signatureStartY + 70)
                e.Graphics.DrawString("(.............................)", normalFont, blackBrush, rightSignatureX + 50, signatureStartY + 80)

                ' Document creation timestamp (separated from signature section)
                Dim timestampY As Integer = pageHeight - 30
                Dim timestamp As String = "Dokumen dibuat pada: " & DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")
                e.Graphics.DrawString(timestamp, smallFont, blackBrush, leftMargin, timestampY)
            End If

            ' Page number (on all pages)
            Dim currentPage As Integer = Math.Ceiling((totalRowsPrinted) / maxRowsThisPage)
            Dim totalPages As Integer = Math.Ceiling(printTotalRows / maxRowsThisPage)
            Dim pageNumberText As String = $"Halaman {currentPage}"

            Dim pageNumberSize As SizeF = e.Graphics.MeasureString(pageNumberText, normalFont)
            e.Graphics.DrawString(pageNumberText, normalFont, blackBrush, rightMargin - pageNumberSize.Width, pageHeight - 30)

            ' Set HasMorePages property
            e.HasMorePages = Not isLastPage

            ' Dispose resources
            titleFont.Dispose()
            subtitleFont.Dispose()
            headerFont.Dispose()
            normalFont.Dispose()
            smallFont.Dispose()
            blackBrush.Dispose()

        Catch ex As Exception
            MessageBox.Show("Error saat mencetak dokumen: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub PrintPreviewDialog1_Load(sender As Object, e As EventArgs) Handles PrintPreviewDialog1.Load

    End Sub

    Private Sub StatusAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set form properties
        Me.Text = "Rekap Status Peminjaman dan Pengembalian"
        Me.WindowState = FormWindowState.Maximized

        ' Initialize ComboBox filter status
        InitializeFilterComboBox()

        ' Load all room booking data when form loads
        LoadAllDataPeminjaman()
    End Sub

    Private Sub InitializeFilterComboBox()
        Try
            ' Clear existing items
            cmbFilterStatus.Items.Clear()

            ' Add filter options
            cmbFilterStatus.Items.Add("Semua")
            cmbFilterStatus.Items.Add("Menunggu")
            cmbFilterStatus.Items.Add("Diterima")
            cmbFilterStatus.Items.Add("Ditolak")
            cmbFilterStatus.Items.Add("Selesai")

            ' Set default selection
            cmbFilterStatus.SelectedIndex = 0 ' "Semua" as default

            ' Set ComboBox properties
            cmbFilterStatus.DropDownStyle = ComboBoxStyle.DropDownList ' Prevent manual editing

        Catch ex As Exception
            MessageBox.Show("Error initializing filter: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LoadAllDataPeminjaman()
        Try
            Using connection As SqlConnection = GetConnection()
                connection.Open()

                ' Query untuk mengambil SEMUA data peminjaman dari semua user
                Dim query As String = "SELECT 
                    p.peminjaman_id,
                    p.user_id,
                    p.ruangan_id,
                    p.tanggal,
                    p.waktu_mulai,
                    p.durasi_peminjaman,
                    p.waktu_selesai,
                    p.status,
                    p.keterangan,
                    p.waktu_pengembalian,
                    p.status_pengembalian,
                    p.keterangan_pengembalian,
                    r.nama_ruangan,
                    r.lokasi,
                    r.kapasitas,
                    u.nama_lengkap
                FROM peminjaman_ruangan p
                INNER JOIN ruangan r ON p.ruangan_id = r.ruangan_id
                INNER JOIN users u ON p.user_id = u.user_id
                ORDER BY p.tanggal DESC, p.waktu_mulai DESC"

                Using command As New SqlCommand(query, connection)
                    Using adapter As New SqlDataAdapter(command)
                        Dim dataTable As New DataTable()
                        adapter.Fill(dataTable)

                        ' Bind data to DataGridView
                        DataGridView1.DataSource = dataTable

                        ' Format DataGridView
                        FormatDataGridView()

                        ' Update status label
                        UpdateStatusLabel(dataTable.Rows.Count)
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub FilterByStatus(status As String)
        Try
            Using connection As SqlConnection = GetConnection()
                connection.Open()

                Dim query As String = "SELECT 
                p.peminjaman_id,
                p.user_id,
                p.ruangan_id,
                p.tanggal,
                p.waktu_mulai,
                p.durasi_peminjaman,
                p.waktu_selesai,
                p.status,
                p.keterangan,
                p.waktu_pengembalian,
                p.status_pengembalian,
                p.keterangan_pengembalian,
                r.nama_ruangan,
                r.lokasi,
                r.kapasitas,
                u.nama_lengkap
            FROM peminjaman_ruangan p
            INNER JOIN ruangan r ON p.ruangan_id = r.ruangan_id
            INNER JOIN users u ON p.user_id = u.user_id"

                If Not String.IsNullOrEmpty(status) AndAlso status <> "Semua" Then
                    query &= " WHERE p.status = @status"
                End If

                query &= " ORDER BY p.tanggal DESC, p.waktu_mulai DESC"

                Using command As New SqlCommand(query, connection)
                    If Not String.IsNullOrEmpty(status) AndAlso status <> "Semua" Then
                        command.Parameters.AddWithValue("@status", status)
                    End If

                    Using adapter As New SqlDataAdapter(command)
                        Dim dataTable As New DataTable()
                        adapter.Fill(dataTable)
                        DataGridView1.DataSource = dataTable

                        ' Format DataGridView after filtering
                        FormatDataGridView()

                        ' Update status label with filter info
                        UpdateStatusLabelWithFilter(dataTable.Rows.Count, status)
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error filtering data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub FormatDataGridView()
        With DataGridView1
            ' Set general properties
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .MultiSelect = False
            .ReadOnly = True
            .AllowUserToAddRows = False
            .AllowUserToDeleteRows = False
            .RowHeadersVisible = False

            ' Set column headers and formatting
            If .Columns.Count > 0 Then
                If .Columns.Contains("peminjaman_id") Then
                    .Columns("peminjaman_id").HeaderText = "ID Peminjaman"
                    .Columns("peminjaman_id").Width = 100
                End If

                If .Columns.Contains("user_id") Then
                    .Columns("user_id").HeaderText = "User ID"
                    .Columns("user_id").Width = 80
                End If

                If .Columns.Contains("ruangan_id") Then
                    .Columns("ruangan_id").HeaderText = "ID Ruangan"
                    .Columns("ruangan_id").Width = 100
                End If

                If .Columns.Contains("tanggal") Then
                    .Columns("tanggal").HeaderText = "Tanggal"
                    .Columns("tanggal").Width = 100
                    .Columns("tanggal").DefaultCellStyle.Format = "dd/MM/yyyy"
                    .Columns("tanggal").DefaultCellStyle.NullValue = "N/A"
                End If

                If .Columns.Contains("waktu_mulai") Then
                    .Columns("waktu_mulai").HeaderText = "Waktu Mulai"
                    .Columns("waktu_mulai").Width = 100
                End If

                If .Columns.Contains("durasi_peminjaman") Then
                    .Columns("durasi_peminjaman").HeaderText = "Durasi"
                    .Columns("durasi_peminjaman").Width = 80
                End If

                If .Columns.Contains("waktu_selesai") Then
                    .Columns("waktu_selesai").HeaderText = "Waktu Selesai"
                    .Columns("waktu_selesai").Width = 100
                End If

                If .Columns.Contains("status") Then
                    .Columns("status").HeaderText = "Status"
                    .Columns("status").Width = 100
                End If

                If .Columns.Contains("keterangan") Then
                    .Columns("keterangan").HeaderText = "Keterangan"
                    .Columns("keterangan").Width = 150
                End If

                If .Columns.Contains("waktu_pengembalian") Then
                    .Columns("waktu_pengembalian").HeaderText = "Waktu Pengembalian"
                    .Columns("waktu_pengembalian").Width = 130
                End If

                If .Columns.Contains("status_pengembalian") Then
                    .Columns("status_pengembalian").HeaderText = "Status Pengembalian"
                    .Columns("status_pengembalian").Width = 130
                End If

                If .Columns.Contains("keterangan_pengembalian") Then
                    .Columns("keterangan_pengembalian").HeaderText = "Keterangan Pengembalian"
                    .Columns("keterangan_pengembalian").Width = 180
                End If

                If .Columns.Contains("nama_ruangan") Then
                    .Columns("nama_ruangan").HeaderText = "Nama Ruangan"
                    .Columns("nama_ruangan").Width = 150
                End If

                If .Columns.Contains("lokasi") Then
                    .Columns("lokasi").HeaderText = "Lokasi"
                    .Columns("lokasi").Width = 120
                End If

                If .Columns.Contains("kapasitas") Then
                    .Columns("kapasitas").HeaderText = "Kapasitas"
                    .Columns("kapasitas").Width = 80
                End If

                If .Columns.Contains("nama_lengkap") Then
                    .Columns("nama_lengkap").HeaderText = "Nama Peminjam"
                    .Columns("nama_lengkap").Width = 150
                End If
            End If

            ' Set alternating row colors
            .AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray
            .DefaultCellStyle.BackColor = Color.White
            .DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise
            .DefaultCellStyle.SelectionForeColor = Color.White
        End With
    End Sub

    Private Sub UpdateStatusLabel(recordCount As Integer)
        ' Update label to show record count
        If Me.Controls.Find("lblStatus", True).Length > 0 Then
            Dim lblStatus As Label = CType(Me.Controls.Find("lblStatus", True)(0), Label)
            lblStatus.Text = $"Total peminjaman: {recordCount} record"
        End If
    End Sub

    Private Sub UpdateStatusLabelWithFilter(recordCount As Integer, filterStatus As String)
        Try
            If Me.Controls.Find("lblStatus", True).Length > 0 Then
                Dim lblStatus As Label = CType(Me.Controls.Find("lblStatus", True)(0), Label)

                If String.IsNullOrEmpty(filterStatus) OrElse filterStatus = "Semua" Then
                    lblStatus.Text = $"Total peminjaman: {recordCount} record"
                Else
                    lblStatus.Text = $"Peminjaman dengan status '{filterStatus}': {recordCount} record"
                End If
            End If
        Catch ex As Exception
            ' Handle error silently or log it
            Console.WriteLine("Error updating status label: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        ' Format status cells with colors
        If DataGridView1.Columns(e.ColumnIndex).Name = "status" Then
            If e.Value IsNot Nothing Then
                Select Case e.Value.ToString().ToLower()
                    Case "diterima", "selesai"
                        e.CellStyle.BackColor = Color.LightGreen
                        e.CellStyle.ForeColor = Color.DarkGreen
                    Case "ditolak"
                        e.CellStyle.BackColor = Color.LightCoral
                        e.CellStyle.ForeColor = Color.DarkRed
                    Case "menunggu"
                        e.CellStyle.BackColor = Color.LightYellow
                        e.CellStyle.ForeColor = Color.DarkOrange
                End Select
            End If
        End If
    End Sub

    ' Helper function untuk konversi string yang aman
    Private Function SafeToString(obj As Object) As String
        If obj Is Nothing OrElse IsDBNull(obj) Then
            Return ""
        Else
            Return obj.ToString()
        End If
    End Function

    Private Function TruncateString(text As String, maxLength As Integer) As String
        If String.IsNullOrEmpty(text) Then
            Return ""
        End If

        If text.Length <= maxLength Then
            Return text
        Else
            Return text.Substring(0, maxLength - 3) & "..."
        End If
    End Function

    ' Method untuk refresh data dari form lain
    Public Sub RefreshData()
        LoadAllDataPeminjaman()
    End Sub

    ' Fungsi koneksi database (perlu disesuaikan dengan konfigurasi Anda)
    Private Function GetConnection() As SqlConnection
        ' Ganti dengan connection string yang sesuai
        Dim connectionString As String = "Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True"
        Return New SqlConnection(connectionString)
    End Function
End Class
﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing

Public Class Dataruangan
    Private connectionString As String = "Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True"
    Private currentImagePath As String = ""
    Private currentRuanganId As Integer = 0
    Private isEditMode As Boolean = False
    Private dummyImage As Image

    Private Sub Dataruangan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CreateDummyImage()
        LoadDataRuangan()
        ClearForm()
    End Sub

    ' Membuat gambar dummy yang tidak akan hilang
    Private Sub CreateDummyImage()
        Try
            ' Buat bitmap 300x300 untuk rasio 1:1
            Dim bmp As New Bitmap(300, 300)
            Using g As Graphics = Graphics.FromImage(bmp)
                ' Background abu-abu muda
                g.Clear(Color.FromArgb(240, 240, 240))

                ' Border
                Using pen As New Pen(Color.Gray, 2)
                    g.DrawRectangle(pen, 1, 1, 298, 298)
                End Using

                ' Icon gambar dummy
                Using brush As New SolidBrush(Color.Gray)
                    ' Gambar icon kamera sederhana
                    g.FillRectangle(brush, 100, 120, 100, 60)
                    g.FillEllipse(brush, 120, 135, 30, 30)

                    ' Text "No Image"
                    Using font As New Font("Arial", 12, FontStyle.Bold)
                        Dim text As String = "No Image"
                        Dim textSize As SizeF = g.MeasureString(text, font)
                        Dim x As Single = (300 - textSize.Width) / 2
                        Dim y As Single = 200
                        g.DrawString(text, font, brush, x, y)
                    End Using
                End Using
            End Using

            dummyImage = bmp
        Catch ex As Exception
            ' Jika gagal membuat dummy image, buat yang sederhana
            dummyImage = New Bitmap(300, 300)
        End Try
    End Sub

    Private Sub LoadDataRuangan()
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim query As String = "SELECT ruangan_id, nama_ruangan, lokasi, kapasitas, gambar_path FROM ruangan ORDER BY ruangan_id"
                Dim da As New SqlDataAdapter(query, conn)
                Dim dt As New DataTable()
                da.Fill(dt)
                DataGridView1.DataSource = dt

                ' Set column headers
                If DataGridView1.Columns.Count > 0 Then
                    DataGridView1.Columns("ruangan_id").HeaderText = "ID"
                    DataGridView1.Columns("nama_ruangan").HeaderText = "Nama Ruangan"
                    DataGridView1.Columns("lokasi").HeaderText = "Lokasi"
                    DataGridView1.Columns("kapasitas").HeaderText = "Kapasitas"
                    DataGridView1.Columns("gambar_path").HeaderText = "Path Gambar"
                    DataGridView1.Columns("ruangan_id").Width = 50
                    DataGridView1.Columns("nama_ruangan").Width = 150
                    DataGridView1.Columns("lokasi").Width = 100
                    DataGridView1.Columns("kapasitas").Width = 80
                    DataGridView1.Columns("gambar_path").Width = 200
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Clear form dengan dummy image
    Private Sub ClearForm()
        txtNamaRuangan.Clear()
        txtLokasi.Clear()
        txtKapasitas.Clear()

        ' Set dummy image instead of Nothing
        If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
            PictureBox1.Image.Dispose()
        End If
        PictureBox1.Image = dummyImage
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom

        currentImagePath = ""
        currentRuanganId = 0
        isEditMode = False
        btnsimpan.Text = "Simpan"
        btnreset.Enabled = True
    End Sub

    ' Fungsi untuk mengubah gambar menjadi 1:1 ratio
    Private Function ResizeImageToSquare(originalImage As Image, size As Integer) As Image
        Dim squareImage As New Bitmap(size, size)

        Using g As Graphics = Graphics.FromImage(squareImage)
            g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            g.PixelOffsetMode = Drawing2D.PixelOffsetMode.HighQuality
            g.CompositingQuality = Drawing2D.CompositingQuality.HighQuality

            ' Fill background dengan warna putih
            g.Clear(Color.White)

            ' Hitung dimensi untuk crop center
            Dim sourceSize As Integer = Math.Min(originalImage.Width, originalImage.Height)
            Dim x As Integer = (originalImage.Width - sourceSize) / 2
            Dim y As Integer = (originalImage.Height - sourceSize) / 2

            ' Crop dan resize ke square
            Dim sourceRect As New Rectangle(x, y, sourceSize, sourceSize)
            Dim destRect As New Rectangle(0, 0, size, size)

            g.DrawImage(originalImage, destRect, sourceRect, GraphicsUnit.Pixel)
        End Using

        Return squareImage
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        DashboardAdmin.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub btneditgambar_Click(sender As Object, e As EventArgs) Handles btneditgambar.Click
        Try
            Dim openFileDialog As New OpenFileDialog()
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif"
            openFileDialog.Title = "Pilih Gambar Ruangan"

            If openFileDialog.ShowDialog() = DialogResult.OK Then
                ' Load gambar original
                Using originalImage As Image = Image.FromFile(openFileDialog.FileName)
                    ' Dispose gambar sebelumnya jika bukan dummy image
                    If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                        PictureBox1.Image.Dispose()
                    End If

                    ' Resize ke 1:1 ratio (300x300)
                    PictureBox1.Image = ResizeImageToSquare(originalImage, 300)
                    PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
                    currentImagePath = openFileDialog.FileName
                End Using
            End If
        Catch ex As Exception
            MessageBox.Show("Error memuat gambar: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnhapusgambar_Click(sender As Object, e As EventArgs) Handles btnhapusgambar.Click
        ' Dispose gambar sebelumnya jika bukan dummy image
        If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
            PictureBox1.Image.Dispose()
        End If

        ' Set kembali ke dummy image
        PictureBox1.Image = dummyImage
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        currentImagePath = ""
        MessageBox.Show("Gambar berhasil dihapus dari preview!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Function CopyImageToAppFolder(sourcePath As String, namaRuangan As String) As String
        Try
            ' Buat folder images jika belum ada
            Dim imagesFolder As String = Path.Combine(Application.StartupPath, "images")
            If Not Directory.Exists(imagesFolder) Then
                Directory.CreateDirectory(imagesFolder)
            End If

            ' Generate nama file baru
            Dim fileExtension As String = ".jpg" ' Selalu simpan sebagai JPG untuk konsistensi
            Dim newFileName As String = namaRuangan.Replace(" ", "_") & "_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & fileExtension
            Dim destinationPath As String = Path.Combine(imagesFolder, newFileName)

            ' Simpan gambar yang sudah di-resize (1:1 ratio) dari PictureBox
            If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                PictureBox1.Image.Save(destinationPath, Imaging.ImageFormat.Jpeg)
            End If

            ' Return relative path
            Return "images\" & newFileName
        Catch ex As Exception
            Throw New Exception("Error copying image: " & ex.Message)
        End Try
    End Function

    Private Sub btnsimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        ' Validasi input
        If String.IsNullOrWhiteSpace(txtNamaRuangan.Text) Then
            MessageBox.Show("Nama ruangan harus diisi!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNamaRuangan.Focus()
            Return
        End If

        If String.IsNullOrWhiteSpace(txtLokasi.Text) Then
            MessageBox.Show("Lokasi harus diisi!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLokasi.Focus()
            Return
        End If

        If String.IsNullOrWhiteSpace(txtKapasitas.Text) OrElse Not IsNumeric(txtKapasitas.Text) Then
            MessageBox.Show("Kapasitas harus diisi dengan angka!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtKapasitas.Focus()
            Return
        End If

        Try
            Dim gambarPath As String = ""

            ' Jika ada gambar yang dipilih (bukan dummy image), copy ke folder aplikasi
            If Not String.IsNullOrEmpty(currentImagePath) AndAlso PictureBox1.Image IsNot dummyImage Then
                gambarPath = CopyImageToAppFolder(currentImagePath, txtNamaRuangan.Text)
            End If

            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim query As String
                Dim cmd As SqlCommand

                If isEditMode Then
                    ' Update data
                    If String.IsNullOrEmpty(gambarPath) AndAlso PictureBox1.Image Is dummyImage Then
                        ' Update tanpa mengubah gambar (masih dummy atau tidak ada perubahan gambar)
                        query = "UPDATE ruangan SET nama_ruangan = @nama, lokasi = @lokasi, kapasitas = @kapasitas WHERE ruangan_id = @id"
                        cmd = New SqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@nama", txtNamaRuangan.Text.Trim())
                        cmd.Parameters.AddWithValue("@lokasi", txtLokasi.Text.Trim())
                        cmd.Parameters.AddWithValue("@kapasitas", Convert.ToInt32(txtKapasitas.Text))
                        cmd.Parameters.AddWithValue("@id", currentRuanganId)
                    Else
                        ' Update dengan gambar baru
                        query = "UPDATE ruangan SET nama_ruangan = @nama, lokasi = @lokasi, kapasitas = @kapasitas, gambar_path = @gambar WHERE ruangan_id = @id"
                        cmd = New SqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@nama", txtNamaRuangan.Text.Trim())
                        cmd.Parameters.AddWithValue("@lokasi", txtLokasi.Text.Trim())
                        cmd.Parameters.AddWithValue("@kapasitas", Convert.ToInt32(txtKapasitas.Text))
                        cmd.Parameters.AddWithValue("@gambar", gambarPath)
                        cmd.Parameters.AddWithValue("@id", currentRuanganId)
                    End If
                Else
                    ' Insert data baru
                    query = "INSERT INTO ruangan (nama_ruangan, lokasi, kapasitas, gambar_path) VALUES (@nama, @lokasi, @kapasitas, @gambar)"
                    cmd = New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@nama", txtNamaRuangan.Text.Trim())
                    cmd.Parameters.AddWithValue("@lokasi", txtLokasi.Text.Trim())
                    cmd.Parameters.AddWithValue("@kapasitas", Convert.ToInt32(txtKapasitas.Text))
                    cmd.Parameters.AddWithValue("@gambar", If(String.IsNullOrEmpty(gambarPath), DBNull.Value, gambarPath))
                End If

                cmd.ExecuteNonQuery()
                MessageBox.Show(If(isEditMode, "Data berhasil diupdate!", "Data berhasil disimpan!"), "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)

                LoadDataRuangan()
                ClearForm()
            End Using

        Catch ex As Exception
            MessageBox.Show("Error menyimpan data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LoadImageToPictureBox(imagePath As String)
        Try
            If File.Exists(imagePath) Then
                ' Dispose gambar sebelumnya jika bukan dummy image
                If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                    PictureBox1.Image.Dispose()
                End If

                ' Load dan resize gambar ke 1:1 ratio
                Using originalImage As Image = Image.FromFile(imagePath)
                    PictureBox1.Image = ResizeImageToSquare(originalImage, 300)
                    PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
                End Using
            Else
                ' File tidak ditemukan, gunakan dummy image
                If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                    PictureBox1.Image.Dispose()
                End If
                PictureBox1.Image = dummyImage
                PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
            End If
        Catch ex As Exception
            ' Error loading image, gunakan dummy image
            If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                PictureBox1.Image.Dispose()
            End If
            PictureBox1.Image = dummyImage
            PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        End Try
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        If e.RowIndex >= 0 Then
            Try
                Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)

                currentRuanganId = Convert.ToInt32(row.Cells("ruangan_id").Value)
                txtNamaRuangan.Text = row.Cells("nama_ruangan").Value.ToString()
                txtLokasi.Text = row.Cells("lokasi").Value.ToString()
                txtKapasitas.Text = row.Cells("kapasitas").Value.ToString()

                ' Load gambar jika ada
                If Not IsDBNull(row.Cells("gambar_path").Value) AndAlso Not String.IsNullOrEmpty(row.Cells("gambar_path").Value.ToString()) Then
                    Dim imagePath As String = Path.Combine(Application.StartupPath, row.Cells("gambar_path").Value.ToString())
                    LoadImageToPictureBox(imagePath)
                Else
                    ' Tidak ada gambar, gunakan dummy image
                    If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                        PictureBox1.Image.Dispose()
                    End If
                    PictureBox1.Image = dummyImage
                    PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
                End If

                isEditMode = True
                btnsimpan.Text = "Update"

            Catch ex As Exception
                MessageBox.Show("Error loading data for edit: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub btnedit_Click(sender As Object, e As EventArgs) Handles btnedit.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Pilih data yang akan diedit!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Try
            Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)

            currentRuanganId = Convert.ToInt32(row.Cells("ruangan_id").Value)
            txtNamaRuangan.Text = row.Cells("nama_ruangan").Value.ToString()
            txtLokasi.Text = row.Cells("lokasi").Value.ToString()
            txtKapasitas.Text = row.Cells("kapasitas").Value.ToString()

            ' Load gambar jika ada
            If Not IsDBNull(row.Cells("gambar_path").Value) AndAlso Not String.IsNullOrEmpty(row.Cells("gambar_path").Value.ToString()) Then
                Dim imagePath As String = Path.Combine(Application.StartupPath, row.Cells("gambar_path").Value.ToString())
                LoadImageToPictureBox(imagePath)
            Else
                ' Tidak ada gambar, gunakan dummy image
                If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                    PictureBox1.Image.Dispose()
                End If
                PictureBox1.Image = dummyImage
                PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
            End If

            isEditMode = True
            btnsimpan.Text = "Update"

        Catch ex As Exception
            MessageBox.Show("Error loading data for edit: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnhapus_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Pilih data yang akan dihapus!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        If MessageBox.Show("Apakah Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)
                Dim ruanganId As Integer = Convert.ToInt32(row.Cells("ruangan_id").Value)
                Dim gambarPath As String = row.Cells("gambar_path").Value.ToString()

                Using conn As New SqlConnection(connectionString)
                    conn.Open()
                    Dim query As String = "DELETE FROM ruangan WHERE ruangan_id = @id"
                    Dim cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@id", ruanganId)
                    cmd.ExecuteNonQuery()

                    ' Hapus file gambar jika ada
                    If Not String.IsNullOrEmpty(gambarPath) Then
                        Dim fullImagePath As String = Path.Combine(Application.StartupPath, gambarPath)
                        If File.Exists(fullImagePath) Then
                            Try
                                File.Delete(fullImagePath)
                            Catch ex As Exception
                                ' Jika tidak bisa hapus file, lanjutkan saja
                            End Try
                        End If
                    End If

                    MessageBox.Show("Data berhasil dihapus!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    LoadDataRuangan()
                    ClearForm()
                End Using

            Catch ex As Exception
                MessageBox.Show("Error menghapus data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        ClearForm()
    End Sub

    Private Sub Dataruangan_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' Dispose semua gambar kecuali dummy image
        If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
            PictureBox1.Image.Dispose()
        End If

        ' Dispose dummy image
        If dummyImage IsNot Nothing Then
            dummyImage.Dispose()
        End If
    End Sub

    Private Sub txtKapasitas_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtKapasitas.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 0 AndAlso Not isEditMode Then
            Try
                Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)

                ' Preview gambar
                If Not IsDBNull(row.Cells("gambar_path").Value) AndAlso Not String.IsNullOrEmpty(row.Cells("gambar_path").Value.ToString()) Then
                    Dim imagePath As String = Path.Combine(Application.StartupPath, row.Cells("gambar_path").Value.ToString())
                    LoadImageToPictureBox(imagePath)
                Else
                    ' Tidak ada gambar, gunakan dummy image
                    If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                        PictureBox1.Image.Dispose()
                    End If
                    PictureBox1.Image = dummyImage
                    PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
                End If

            Catch ex As Exception
                ' Handle error silently untuk preview, gunakan dummy image
                If PictureBox1.Image IsNot Nothing AndAlso PictureBox1.Image IsNot dummyImage Then
                    PictureBox1.Image.Dispose()
                End If
                PictureBox1.Image = dummyImage
                PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
            End Try
        End If
    End Sub
End Class
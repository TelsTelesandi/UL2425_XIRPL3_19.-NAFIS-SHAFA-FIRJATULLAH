﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Konfirmasi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Konfirmasi))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtptanggal = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnkonfirmasi = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtketerangan = New System.Windows.Forms.TextBox()
        Me.cmbjamselesai = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbjammulai = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbtotaljp = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblkapasitas = New System.Windows.Forms.Label()
        Me.lbllokasi = New System.Windows.Forms.Label()
        Me.lblnamaruangan = New System.Windows.Forms.Label()
        Me.btnbatal = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(102, 32)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(259, 236)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnbatal)
        Me.GroupBox1.Controls.Add(Me.dtptanggal)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.btnkonfirmasi)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtketerangan)
        Me.GroupBox1.Controls.Add(Me.cmbjamselesai)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.cmbjammulai)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.cmbtotaljp)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblkapasitas)
        Me.GroupBox1.Controls.Add(Me.lbllokasi)
        Me.GroupBox1.Controls.Add(Me.lblnamaruangan)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(36, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(481, 678)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Konfirmasi Peminjaman"
        '
        'dtptanggal
        '
        Me.dtptanggal.Location = New System.Drawing.Point(193, 378)
        Me.dtptanggal.Name = "dtptanggal"
        Me.dtptanggal.Size = New System.Drawing.Size(246, 20)
        Me.dtptanggal.TabIndex = 30
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(42, 378)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Pilih Tanggal :"
        '
        'btnkonfirmasi
        '
        Me.btnkonfirmasi.Location = New System.Drawing.Point(63, 603)
        Me.btnkonfirmasi.Name = "btnkonfirmasi"
        Me.btnkonfirmasi.Size = New System.Drawing.Size(167, 41)
        Me.btnkonfirmasi.TabIndex = 28
        Me.btnkonfirmasi.Text = "KONFIRMASI"
        Me.btnkonfirmasi.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(42, 485)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 13)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Keterangan :"
        '
        'txtketerangan
        '
        Me.txtketerangan.Location = New System.Drawing.Point(193, 485)
        Me.txtketerangan.Multiline = True
        Me.txtketerangan.Name = "txtketerangan"
        Me.txtketerangan.Size = New System.Drawing.Size(246, 88)
        Me.txtketerangan.TabIndex = 26
        '
        'cmbjamselesai
        '
        Me.cmbjamselesai.FormattingEnabled = True
        Me.cmbjamselesai.Location = New System.Drawing.Point(193, 457)
        Me.cmbjamselesai.Name = "cmbjamselesai"
        Me.cmbjamselesai.Size = New System.Drawing.Size(246, 21)
        Me.cmbjamselesai.TabIndex = 25
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(42, 460)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(91, 13)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Pilih Jam Selesai :"
        '
        'cmbjammulai
        '
        Me.cmbjammulai.FormattingEnabled = True
        Me.cmbjammulai.Location = New System.Drawing.Point(193, 430)
        Me.cmbjammulai.Name = "cmbjammulai"
        Me.cmbjammulai.Size = New System.Drawing.Size(246, 21)
        Me.cmbjammulai.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(42, 433)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Pilih Jam Mulai :"
        '
        'cmbtotaljp
        '
        Me.cmbtotaljp.FormattingEnabled = True
        Me.cmbtotaljp.Location = New System.Drawing.Point(193, 403)
        Me.cmbtotaljp.Name = "cmbtotaljp"
        Me.cmbtotaljp.Size = New System.Drawing.Size(246, 21)
        Me.cmbtotaljp.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(42, 406)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Pilih Total Jam Pelajaran :"
        '
        'lblkapasitas
        '
        Me.lblkapasitas.AutoSize = True
        Me.lblkapasitas.BackColor = System.Drawing.Color.White
        Me.lblkapasitas.ForeColor = System.Drawing.Color.Black
        Me.lblkapasitas.Location = New System.Drawing.Point(308, 342)
        Me.lblkapasitas.Name = "lblkapasitas"
        Me.lblkapasitas.Size = New System.Drawing.Size(100, 13)
        Me.lblkapasitas.TabIndex = 19
        Me.lblkapasitas.Text = "(kapasitas ruangan)"
        '
        'lbllokasi
        '
        Me.lbllokasi.AutoSize = True
        Me.lbllokasi.BackColor = System.Drawing.Color.White
        Me.lbllokasi.ForeColor = System.Drawing.Color.Black
        Me.lbllokasi.Location = New System.Drawing.Point(42, 342)
        Me.lbllokasi.Name = "lbllokasi"
        Me.lbllokasi.Size = New System.Drawing.Size(86, 13)
        Me.lbllokasi.TabIndex = 18
        Me.lbllokasi.Text = "(Lokasi ruangan)"
        '
        'lblnamaruangan
        '
        Me.lblnamaruangan.AutoSize = True
        Me.lblnamaruangan.BackColor = System.Drawing.Color.White
        Me.lblnamaruangan.Font = New System.Drawing.Font("Akira Expanded", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnamaruangan.ForeColor = System.Drawing.Color.Black
        Me.lblnamaruangan.Location = New System.Drawing.Point(47, 299)
        Me.lblnamaruangan.Name = "lblnamaruangan"
        Me.lblnamaruangan.Size = New System.Drawing.Size(368, 30)
        Me.lblnamaruangan.TabIndex = 17
        Me.lblnamaruangan.Text = "(NAMA RUANGAN)"
        '
        'btnbatal
        '
        Me.btnbatal.Location = New System.Drawing.Point(236, 603)
        Me.btnbatal.Name = "btnbatal"
        Me.btnbatal.Size = New System.Drawing.Size(167, 41)
        Me.btnbatal.TabIndex = 31
        Me.btnbatal.Text = "BATAL"
        Me.btnbatal.UseVisualStyleBackColor = True
        '
        'Konfirmasi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkCyan
        Me.ClientSize = New System.Drawing.Size(548, 737)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Konfirmasi"
        Me.Text = "Konfirmasi"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents cmbjammulai As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cmbtotaljp As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblkapasitas As Label
    Friend WithEvents lbllokasi As Label
    Friend WithEvents lblnamaruangan As Label
    Friend WithEvents btnkonfirmasi As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents txtketerangan As TextBox
    Friend WithEvents cmbjamselesai As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents dtptanggal As DateTimePicker
    Friend WithEvents btnbatal As Button
End Class

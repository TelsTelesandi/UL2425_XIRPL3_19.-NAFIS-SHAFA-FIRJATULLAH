﻿Imports System.Data.SqlClient

Public Class Approve
    ' Connection string - sesuaikan dengan database Anda
    Private connectionString As String = "Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True"
    Private dt As DataTable
    Private adapter As SqlDataAdapter

    Private Sub FormPengambalianRuangan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPendingData()
    End Sub

    ' Fungsi untuk memuat data yang berstatus "menunggu"
    Private Sub LoadPendingData()
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' Query untuk menggabungkan data dari 3 tabel
                Dim query As String = "
                SELECT 
                    p.peminjaman_id,
                    p.user_id,
                    p.ruangan_id,
                    p.tanggal,
                    p.waktu_mulai,
                    p.durasi_peminjaman,
                    p.waktu_selesai,
                    p.status,
                    u.id_card,
                    u.nama_lengkap,
                    r.nama_ruangan
                FROM peminjaman_ruangan p
                INNER JOIN users u ON p.user_id = u.user_id
                INNER JOIN ruangan r ON p.ruangan_id = r.ruangan_id
                WHERE p.status = 'menunggu'
                ORDER BY p.tanggal, p.waktu_mulai"

                adapter = New SqlDataAdapter(query, conn)
                dt = New DataTable()
                adapter.Fill(dt)

                ' Bind data ke DataGridView (asumsikan nama DataGridView adalah dgvPeminjaman)
                If dgvPeminjaman IsNot Nothing Then
                    dgvPeminjaman.DataSource = dt
                    FormatDataGridView()
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Format DataGridView untuk menampilkan kolom yang diperlukan
    Private Sub FormatDataGridView()
        With dgvPeminjaman
            .AutoGenerateColumns = False
            .Columns.Clear()

            ' Kolom tersembunyi untuk ID
            Dim colID As New DataGridViewTextBoxColumn()
            colID.Name = "peminjaman_id"
            colID.DataPropertyName = "peminjaman_id"
            colID.Visible = False
            .Columns.Add(colID)

            ' ID Card
            Dim colIDCard As New DataGridViewTextBoxColumn()
            colIDCard.Name = "id_card"
            colIDCard.DataPropertyName = "id_card"
            colIDCard.HeaderText = "ID Card"
            colIDCard.Width = 100
            .Columns.Add(colIDCard)

            ' Nama Lengkap
            Dim colNama As New DataGridViewTextBoxColumn()
            colNama.Name = "nama_lengkap"
            colNama.DataPropertyName = "nama_lengkap"
            colNama.HeaderText = "Nama Lengkap"
            colNama.Width = 150
            .Columns.Add(colNama)

            ' Nama Ruangan
            Dim colRuangan As New DataGridViewTextBoxColumn()
            colRuangan.Name = "nama_ruangan"
            colRuangan.DataPropertyName = "nama_ruangan"
            colRuangan.HeaderText = "Nama Ruangan"
            colRuangan.Width = 120
            .Columns.Add(colRuangan)

            ' Tanggal
            Dim colTanggal As New DataGridViewTextBoxColumn()
            colTanggal.Name = "tanggal"
            colTanggal.DataPropertyName = "tanggal"
            colTanggal.HeaderText = "Tanggal"
            colTanggal.Width = 100
            .Columns.Add(colTanggal)

            ' Waktu Mulai
            Dim colWaktuMulai As New DataGridViewTextBoxColumn()
            colWaktuMulai.Name = "waktu_mulai"
            colWaktuMulai.DataPropertyName = "waktu_mulai"
            colWaktuMulai.HeaderText = "Waktu Mulai"
            colWaktuMulai.Width = 100
            .Columns.Add(colWaktuMulai)

            ' Durasi Peminjaman
            Dim colDurasi As New DataGridViewTextBoxColumn()
            colDurasi.Name = "durasi_peminjaman"
            colDurasi.DataPropertyName = "durasi_peminjaman"
            colDurasi.HeaderText = "Durasi"
            colDurasi.Width = 80
            .Columns.Add(colDurasi)

            ' Waktu Selesai
            Dim colWaktuSelesai As New DataGridViewTextBoxColumn()
            colWaktuSelesai.Name = "waktu_selesai"
            colWaktuSelesai.DataPropertyName = "waktu_selesai"
            colWaktuSelesai.HeaderText = "Waktu Selesai"
            colWaktuSelesai.Width = 100
            .Columns.Add(colWaktuSelesai)

            ' Status
            Dim colStatus As New DataGridViewTextBoxColumn()
            colStatus.Name = "status"
            colStatus.DataPropertyName = "status"
            colStatus.HeaderText = "Status"
            colStatus.Width = 80
            .Columns.Add(colStatus)

            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .MultiSelect = False
        End With
    End Sub
    Private Sub btnterima_Click(sender As Object, e As EventArgs) Handles btnterima.Click
        If dgvPeminjaman.SelectedRows.Count = 0 Then
            MessageBox.Show("Silakan pilih data yang akan diterima!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim selectedRow As DataGridViewRow = dgvPeminjaman.SelectedRows(0)
        Dim peminjamanId As Integer = Convert.ToInt32(selectedRow.Cells("peminjaman_id").Value)
        Dim namaLengkap As String = selectedRow.Cells("nama_lengkap").Value.ToString()
        Dim namaRuangan As String = selectedRow.Cells("nama_ruangan").Value.ToString()

        Dim result As DialogResult = MessageBox.Show(
            $"Apakah Anda yakin ingin menerima peminjaman ruangan '{namaRuangan}' oleh '{namaLengkap}'?",
            "Konfirmasi Terima",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            UpdateStatus(peminjamanId, "diterima")
        End If
    End Sub

    Private Sub btntolak_Click(sender As Object, e As EventArgs) Handles btntolak.Click
        If dgvpeminjaman.SelectedRows.Count = 0 Then
            MessageBox.Show("Silakan pilih data yang akan ditolak!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim selectedRow As DataGridViewRow = dgvpeminjaman.SelectedRows(0)
        Dim peminjamanId As Integer = Convert.ToInt32(selectedRow.Cells("peminjaman_id").Value)
        Dim namaLengkap As String = selectedRow.Cells("nama_lengkap").Value.ToString()
        Dim namaRuangan As String = selectedRow.Cells("nama_ruangan").Value.ToString()

        Dim result As DialogResult = MessageBox.Show(
            $"Apakah Anda yakin ingin menolak peminjaman ruangan '{namaRuangan}' oleh '{namaLengkap}'?",
            "Konfirmasi Tolak",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            UpdateStatus(peminjamanId, "ditolak")
        End If
    End Sub
    Private Sub UpdateStatus(peminjamanId As Integer, newStatus As String)
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                Dim query As String = "UPDATE peminjaman_ruangan SET status = @status WHERE peminjaman_id = @id"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@status", newStatus)
                    cmd.Parameters.AddWithValue("@id", peminjamanId)

                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        Dim statusText As String = If(newStatus = "diterima", "diterima", "ditolak")
                        MessageBox.Show($"Peminjaman berhasil {statusText}!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        ' Refresh data untuk menghilangkan record yang sudah diupdate
                        LoadPendingData()
                    Else
                        MessageBox.Show("Gagal mengupdate status peminjaman!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error updating status: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Approve_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If adapter IsNot Nothing Then
            adapter.Dispose()
        End If
        If dt IsNot Nothing Then
            dt.Dispose()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        DashboardAdmin.Show()
    End Sub
End Class
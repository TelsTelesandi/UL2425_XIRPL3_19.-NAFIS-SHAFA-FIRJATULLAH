﻿Imports System.Data.SqlClient
Imports System.IO

Public Class PeminjamanRuangan
    Private Sub PeminjamanRuangan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim conn As New SqlConnection("Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True")
        Dim cmd As New SqlCommand("SELECT * FROM ruangan", conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        FlowLayoutPanel1.Controls.Clear()

        For Each row As DataRow In dt.Rows
            Dim panel As New Panel With {.Width = 500, .Height = 150, .BorderStyle = BorderStyle.FixedSingle}

            ' PictureBox
            Dim pic As New PictureBox With {.Width = 120, .Height = 120, .Left = 10, .Top = 10, .SizeMode = PictureBoxSizeMode.Zoom}
            Dim gambarPath As String = Path.Combine(Application.StartupPath, row("gambar_path").ToString())
            If File.Exists(gambarPath) Then
                pic.Image = Image.FromFile(gambarPath)
            Else
                MessageBox.Show("Gambar tidak ditemukan: " & gambarPath)
            End If
            panel.Controls.Add(pic)

            ' Label Nama Ruangan
            Dim lblNama As New Label With {
                .Text = row("nama_ruangan").ToString(),
                .Font = New Font("Impact", 16, FontStyle.Bold),
                .Left = 140, .Top = 10,
                .AutoSize = True
            }
            panel.Controls.Add(lblNama)

            ' Label Lokasi
            Dim lblLokasi As New Label With {
                .Text = "(" & row("lokasi").ToString() & ")",
                .Left = 140, .Top = 40,
                .ForeColor = Color.SteelBlue,
                .AutoSize = True
            }
            panel.Controls.Add(lblLokasi)

            ' Label Kapasitas
            Dim lblKapasitas As New Label With {
                .Text = "(" & row("kapasitas").ToString() & " orang)",
                .Left = 140, .Top = 60,
                .AutoSize = True
            }
            panel.Controls.Add(lblKapasitas)

            ' Tombol Masuk
            Dim btnMasuk As New Button With {
                .Text = "MASUK",
                .Left = 400, .Top = 100,
                .Width = 80
            }
            panel.Controls.Add(btnMasuk)
            FlowLayoutPanel1.Controls.Add(panel)

            ' PERBAIKAN: Tambahkan handler tombol MASUK dengan ruangan_id
            AddHandler btnMasuk.Click, Sub(s, ev)
                                           Try
                                               Dim frmKonfirmasi As New Konfirmasi()

                                               ' Kirim semua data ke form konfirmasi termasuk RuanganId
                                               frmKonfirmasi.GambarPath = gambarPath
                                               frmKonfirmasi.NamaRuangan = row("nama_ruangan").ToString()
                                               frmKonfirmasi.Lokasi = row("lokasi").ToString()
                                               frmKonfirmasi.Kapasitas = row("kapasitas").ToString()

                                               ' YANG TERPENTING: Set RuanganId dari database
                                               frmKonfirmasi.RuanganId = Convert.ToInt32(row("ruangan_id"))

                                               ' Debug: Tampilkan RuanganId untuk memastikan terkirim
                                               ' MessageBox.Show("Mengirim RuanganId: " & row("ruangan_id").ToString(), "Debug")

                                               frmKonfirmasi.ShowDialog()
                                           Catch ex As Exception
                                               MessageBox.Show("Error saat membuka form konfirmasi: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                           End Try
                                       End Sub
        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        DashboardUser.Show()
    End Sub
End Class
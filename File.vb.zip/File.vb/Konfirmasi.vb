﻿Imports System.Data.SqlClient

Public Class Konfirmasi
    ' Properti publik untuk menerima data
    Public Property GambarPath As String
    Public Property NamaRuangan As String
    Public Property Lokasi As String
    Public Property Kapasitas As String
    Public Property RuanganId As Integer

    ' Connection string - menggunakan dari Module1
    Private connStr As String = Module1.ConnectionString

    Private Sub Konfirmasi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Validasi user session terlebih dahulu
        If Not UserSession.CurrentUser.isLoggedIn OrElse UserSession.CurrentUser.user_id <= 0 Then
            MessageBox.Show("Anda belum login! Silakan login terlebih dahulu.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Me.Close()
            Return
        End If

        ' Tampilkan gambar jika ada
        If IO.File.Exists(GambarPath) Then
            PictureBox1.Image = Image.FromFile(GambarPath)
            PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        End If

        ' Tampilkan data ruangan
        lblnamaruangan.Text = NamaRuangan
        lbllokasi.Text = "(" & Lokasi & ")"
        lblkapasitas.Text = "(" & Kapasitas & " orang)"

        ' Debug: Cek apakah RuanganId sudah ter-set dengan benar
        If RuanganId <= 0 Then
            MessageBox.Show("Warning: RuanganId belum di-set! Nilai saat ini: " & RuanganId.ToString() & vbCrLf &
                          "Pastikan properti RuanganId diisi sebelum membuka form ini.",
                          "Debug Info", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If

        ' Set tanggal default ke hari ini (hanya tanggal, tanpa jam)
        dtptanggal.Value = DateTime.Now.Date
        dtptanggal.Format = DateTimePickerFormat.Short ' Hanya tampilkan tanggal

        ' Isi ComboBox Total Jam Pelajaran
        cmbtotaljp.Items.Clear()
        For i As Integer = 1 To 10
            cmbtotaljp.Items.Add(i.ToString() & "JP")
        Next

        ' Isi Jam Mulai dan Selesai (08:00 - 15:00)
        cmbjammulai.Items.Clear()
        cmbjamselesai.Items.Clear()

        Dim jam As DateTime = DateTime.Parse("08:00")
        While jam <= DateTime.Parse("15:00")
            Dim waktu As String = jam.ToString("HH:mm")
            cmbjammulai.Items.Add(waktu)
            cmbjamselesai.Items.Add(waktu)
            jam = jam.AddMinutes(30) ' Interval 30 menit
        End While

        ' Set nilai default
        cmbjammulai.SelectedIndex = 0 ' 08:00
        cmbjamselesai.SelectedIndex = 2 ' 09:00
        cmbtotaljp.SelectedIndex = 0 ' 1JP
    End Sub

    Private Sub btnKonfirmasi_Click(sender As Object, e As EventArgs) Handles btnkonfirmasi.Click
        ' Validasi session user terlebih dahulu
        If Not ValidasiUserSession() Then
            Return
        End If

        ' Validasi input
        If Not ValidasiInput() Then
            Return
        End If

        Try
            ' Simpan data peminjaman
            If SimpanPeminjaman() Then
                MessageBox.Show("Permintaan Peminjaman telah di kirim. Silahkan cek status konfirmasi di form status", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.Close()
            Else
                MessageBox.Show("Gagal menyimpan data peminjaman!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show("Terjadi kesalahan: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function ValidasiUserSession() As Boolean
        ' Cek apakah user sudah login
        If Not UserSession.CurrentUser.isLoggedIn Then
            MessageBox.Show("Anda belum login! Silakan login terlebih dahulu.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Cek apakah user_id valid
        If UserSession.CurrentUser.user_id <= 0 Then
            MessageBox.Show("User ID tidak valid! Silakan login ulang.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Validasi user masih ada di database
        If Not ValidasiUserDiDatabase() Then
            MessageBox.Show("User tidak ditemukan di database! Silakan login ulang.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        Return True
    End Function

    Private Function ValidasiUserDiDatabase() As Boolean
        Try
            Using conn As New SqlConnection(connStr)
                conn.Open()
                Dim query As String = "SELECT COUNT(*) FROM users WHERE user_id = @user_id"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@user_id", UserSession.CurrentUser.user_id)
                    Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error saat validasi user: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Function ValidasiInput() As Boolean
        ' Debug: Tampilkan RuanganId untuk troubleshooting
        ' MessageBox.Show("Debug: RuanganId = " & RuanganId.ToString(), "Debug")

        ' Validasi ruangan ID - hapus validasi ini untuk sementara karena mungkin RuanganId tidak ter-set
        ' If RuanganId <= 0 Then
        '     MessageBox.Show("ID Ruangan tidak valid!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '     Return False
        ' End If

        ' Validasi tanggal
        If dtptanggal.Value.Date < DateTime.Now.Date Then
            MessageBox.Show("Tanggal tidak boleh kurang dari hari ini!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            dtptanggal.Focus()
            Return False
        End If

        ' Validasi jam mulai
        If cmbjammulai.SelectedIndex = -1 Then
            MessageBox.Show("Pilih jam mulai terlebih dahulu!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbjammulai.Focus()
            Return False
        End If

        ' Validasi jam selesai
        If cmbjamselesai.SelectedIndex = -1 Then
            MessageBox.Show("Pilih jam selesai terlebih dahulu!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbjamselesai.Focus()
            Return False
        End If

        ' Validasi total JP
        If cmbtotaljp.SelectedIndex = -1 Then
            MessageBox.Show("Pilih total jam pelajaran terlebih dahulu!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbtotaljp.Focus()
            Return False
        End If

        ' Validasi keterangan
        If String.IsNullOrWhiteSpace(txtketerangan.Text) Then
            MessageBox.Show("Keterangan tidak boleh kosong!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtketerangan.Focus()
            Return False
        End If

        ' Validasi jam mulai harus lebih kecil dari jam selesai
        Dim jamMulai As DateTime = DateTime.Parse(cmbjammulai.SelectedItem.ToString())
        Dim jamSelesai As DateTime = DateTime.Parse(cmbjamselesai.SelectedItem.ToString())

        If jamMulai >= jamSelesai Then
            MessageBox.Show("Jam mulai harus lebih kecil dari jam selesai!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbjamselesai.Focus()
            Return False
        End If

        ' Cek apakah ruangan sudah dipinjam pada waktu yang sama
        If CekBentrokWaktu() Then
            MessageBox.Show("Ruangan sudah dipinjam pada waktu tersebut!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        Return True
    End Function

    Private Function CekBentrokWaktu() As Boolean
        Try
            Using conn As New SqlConnection(connStr)
                conn.Open()

                ' Cek bentrok waktu untuk status yang bukan 'ditolak' atau 'dibatalkan'
                Dim query As String = "SELECT COUNT(*) FROM peminjaman_ruangan WHERE ruangan_id = @ruangan_id AND tanggal = @tanggal AND status NOT IN ('ditolak', 'dibatalkan') AND " &
                                    "((@jam_mulai >= waktu_mulai AND @jam_mulai < waktu_selesai) OR " &
                                    "(@jam_selesai > waktu_mulai AND @jam_selesai <= waktu_selesai) OR " &
                                    "(@jam_mulai <= waktu_mulai AND @jam_selesai >= waktu_selesai))"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@ruangan_id", RuanganId)
                    cmd.Parameters.AddWithValue("@tanggal", dtptanggal.Value.Date)
                    cmd.Parameters.AddWithValue("@jam_mulai", cmbjammulai.SelectedItem.ToString())
                    cmd.Parameters.AddWithValue("@jam_selesai", cmbjamselesai.SelectedItem.ToString())

                    Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error saat mengecek bentrok waktu: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return True ' Anggap bentrok jika error untuk keamanan
        End Try
    End Function

    Private Function SimpanPeminjaman() As Boolean
        Try
            ' Validasi final untuk RuanganId sebelum menyimpan
            If RuanganId <= 0 Then
                MessageBox.Show("Error: ID Ruangan tidak valid (" & RuanganId.ToString() & ")! " & vbCrLf &
                              "Tidak dapat menyimpan peminjaman.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If

            Using conn As New SqlConnection(connStr)
                conn.Open()

                Dim query As String = "INSERT INTO peminjaman_ruangan (user_id, ruangan_id, tanggal, waktu_mulai, durasi_peminjaman, waktu_selesai, status, keterangan, waktu_pengembalian, status_pengembalian, keterangan_pengembalian) " &
                                    "VALUES (@user_id, @ruangan_id, @tanggal, @waktu_mulai, @durasi_peminjaman, @waktu_selesai, @status, @keterangan, @waktu_pengembalian, @status_pengembalian, @keterangan_pengembalian)"

                Using cmd As New SqlCommand(query, conn)
                    ' Menggunakan user_id dari UserSession
                    cmd.Parameters.AddWithValue("@user_id", UserSession.CurrentUser.user_id)

                    ' PERBAIKAN 1: Pastikan RuanganId terisi dengan benar
                    cmd.Parameters.AddWithValue("@ruangan_id", RuanganId)

                    ' PERBAIKAN 2: Simpan hanya tanggal tanpa jam
                    cmd.Parameters.AddWithValue("@tanggal", dtptanggal.Value.Date)

                    cmd.Parameters.AddWithValue("@waktu_mulai", cmbjammulai.SelectedItem.ToString())
                    cmd.Parameters.AddWithValue("@durasi_peminjaman", cmbtotaljp.SelectedItem.ToString())
                    cmd.Parameters.AddWithValue("@waktu_selesai", cmbjamselesai.SelectedItem.ToString())

                    ' PERBAIKAN 3: Status default "menunggu" bukan "selesai"
                    cmd.Parameters.AddWithValue("@status", "menunggu")

                    cmd.Parameters.AddWithValue("@keterangan", txtketerangan.Text.Trim())

                    ' Data yang dikosongkan sesuai permintaan
                    cmd.Parameters.AddWithValue("@waktu_pengembalian", DBNull.Value)
                    cmd.Parameters.AddWithValue("@status_pengembalian", DBNull.Value)
                    cmd.Parameters.AddWithValue("@keterangan_pengembalian", DBNull.Value)

                    Dim result As Integer = cmd.ExecuteNonQuery()
                    Return result > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error saat menyimpan data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub cmbJamMulai_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbjammulai.SelectedIndexChanged
        ' Auto set jam selesai berdasarkan durasi JP yang dipilih
        If cmbjammulai.SelectedIndex <> -1 AndAlso cmbtotaljp.SelectedIndex <> -1 Then
            SetJamSelesaiOtomatis()
        End If
    End Sub

    Private Sub cmbTotalJP_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbtotaljp.SelectedIndexChanged
        ' Auto set jam selesai berdasarkan jam mulai dan durasi JP
        If cmbjammulai.SelectedIndex <> -1 AndAlso cmbtotaljp.SelectedIndex <> -1 Then
            SetJamSelesaiOtomatis()
        End If
    End Sub

    Private Sub SetJamSelesaiOtomatis()
        Try
            Dim jamMulai As DateTime = DateTime.Parse(cmbjammulai.SelectedItem.ToString())
            Dim totalJP As Integer = Integer.Parse(cmbtotaljp.SelectedItem.ToString().Replace("JP", ""))

            ' Asumsikan 1 JP = 45 menit
            Dim jamSelesai As DateTime = jamMulai.AddMinutes(totalJP * 45)

            ' Cari index jam selesai yang paling mendekati
            For i As Integer = 0 To cmbjamselesai.Items.Count - 1
                Dim waktuItem As DateTime = DateTime.Parse(cmbjamselesai.Items(i).ToString())
                If waktuItem >= jamSelesai Then
                    cmbjamselesai.SelectedIndex = i
                    Exit For
                End If
            Next

        Catch ex As Exception
            ' Ignore error, biarkan user pilih manual
        End Try
    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnbatal.Click
        If MessageBox.Show("Apakah Anda yakin ingin membatalkan peminjaman?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub
End Class
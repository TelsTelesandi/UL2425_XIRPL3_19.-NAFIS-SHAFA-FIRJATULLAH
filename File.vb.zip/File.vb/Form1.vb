﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Text

Public Class Form1
    ' Fungsi Hash Password
    Private Function HashPassword(input As String) As String
        Using sha256 As SHA256 = SHA256.Create()
            Dim bytes As Byte() = Encoding.UTF8.GetBytes(input)
            Dim hash As Byte() = sha256.ComputeHash(bytes)
            Return BitConverter.ToString(hash).Replace("-", "")
        End Using
    End Function

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            txtpass.PasswordChar = ""
        Else
            txtpass.PasswordChar = "*"
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        UserSession.ClearSession()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Try
            ' Validasi input
            If String.IsNullOrEmpty(txtusername.Text) OrElse String.IsNullOrEmpty(txtpass.Text) Then
                MessageBox.Show("Username dan Password harus diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Hash password yang dimasukkan user
            Dim hashedPassword As String = HashPassword(txtpass.Text.Trim())

            ' Koneksi database
            Dim connectionString As String = "Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True"
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' Query untuk validasi login dengan hashed password
                Dim query As String = "SELECT user_id, username, role, jenis_pengguna, nama_lengkap FROM users WHERE username = @username AND password = @password"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@username", txtusername.Text.Trim())
                    cmd.Parameters.AddWithValue("@password", hashedPassword)

                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            ' Login berhasil, simpan data user ke session
                            UserSession.CurrentUser.user_id = Convert.ToInt32(reader("user_id"))
                            UserSession.CurrentUser.username = reader("username").ToString()
                            UserSession.CurrentUser.role = reader("role").ToString()
                            UserSession.CurrentUser.jenis_pengguna = reader("jenis_pengguna").ToString()
                            UserSession.CurrentUser.nama_lengkap = reader("nama_lengkap").ToString()
                            UserSession.CurrentUser.isLoggedIn = True

                            MessageBox.Show($"Selamat datang, {UserSession.CurrentUser.nama_lengkap}!", "Login Berhasil", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            ' Arahkan ke dashboard berdasarkan role 
                            RedirectToDashboard()

                        Else
                            MessageBox.Show("Username atau Password salah!", "Login Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            txtpass.Clear()
                            txtusername.Focus()
                        End If
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub RedirectToDashboard()
        Try
            Select Case UserSession.CurrentUser.role.ToLower().Trim()
                Case "admin"
                    Dim adminDashboard As New DashboardAdmin()
                    adminDashboard.Show()
                    Me.Hide()

                Case "user"
                    Dim userDashboard As New DashboardUser()
                    userDashboard.Show()
                    Me.Hide()

                Case Else
                    MessageBox.Show($"Role '{UserSession.CurrentUser.role}' tidak dikenali dalam sistem!", "Error Role", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    UserSession.ClearSession()
                    Return
            End Select

        Catch ex As Exception
            MessageBox.Show($"Error saat membuka dashboard: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class

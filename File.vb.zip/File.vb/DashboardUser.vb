﻿Public Class DashboardUser
    Private Sub DashboardUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Tampilkan nama lengkap user yang sedang login
        DisplayUserInfo()

        ' Set form properties
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
    End Sub
    Private Sub DisplayUserInfo()
        Try
            ' Pastikan user sudah login
            If UserSession.CurrentUser.isLoggedIn Then
                ' Update text "HALO (NAMA LENGKAP)" 
                ' Asumsikan Anda memiliki Label dengan nama lblWelcome
                LBLWELCOME.Text = $"HALO {UserSession.CurrentUser.nama_lengkap.ToUpper()}"
            Else
                ' Jika session tidak valid, kembali ke login
                MessageBox.Show("Session tidak valid. Silakan login kembali.", "Session Expired", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ReturnToLogin()
            End If
        Catch ex As Exception
            MessageBox.Show($"Error saat menampilkan informasi user: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ReturnToLogin()
        Try
            UserSession.ClearSession()
            Dim loginForm As New Form1()
            loginForm.Show()
            Me.Close()
        Catch ex As Exception
            MessageBox.Show($"Error saat kembali ke login: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim result As DialogResult = MessageBox.Show("Apakah Anda yakin ingin logout?", "Konfirmasi Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                ReturnToLogin()
            End If
        Catch ex As Exception
            MessageBox.Show($"Error saat logout: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Public Sub RefreshUserInfo()
        DisplayUserInfo()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PeminjamanRuangan.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        PengembalianRuangan.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        StatusUser.Show()
        Me.Hide()
    End Sub
End Class
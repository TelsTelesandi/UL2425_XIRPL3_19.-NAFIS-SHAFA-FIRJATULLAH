﻿Imports System.Collections.Specialized.BitVector32
Imports System.Data.SqlClient
Imports System.IO

Public Class PengembalianRuangan
    Private connectionString As String = "Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True"
    Private selectedPeminjamanId As Integer = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        DashboardUser.Show()
    End Sub

    Private Sub PengembalianRuangan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetupForm()
        LoadDataPeminjaman()
    End Sub

    Private Sub SetupForm()
        ' Setup DataGridView
        With DataGridView1
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .MultiSelect = False
            .ReadOnly = True
        End With

        ' Setup TextBox
        txtnamaruangan.ReadOnly = True
        txtwaktu.Text = "HH:MM (contoh: 14:30)"

        ' Clear form initially
        ClearForm()
    End Sub

    ' Helper function untuk menghandle null values dari database
    Private Function GetSafeStringValue(cellValue As Object) As String
        If cellValue Is Nothing OrElse IsDBNull(cellValue) Then
            Return ""
        Else
            Return cellValue.ToString()
        End If
    End Function

    Private Function GetSafeIntValue(cellValue As Object) As Integer
        If cellValue Is Nothing OrElse IsDBNull(cellValue) Then
            Return 0
        Else
            Try
                Return Convert.ToInt32(cellValue)
            Catch
                Return 0
            End Try
        End If
    End Function

    Private Sub LoadDataPeminjaman()
        Try
            ' Validasi user session
            If UserSession.CurrentUser Is Nothing Then
                MessageBox.Show("User session tidak valid. Silakan login kembali.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            Dim currentUserId As Integer = UserSession.CurrentUser.user_id

            Using connection As New SqlConnection(connectionString)
                connection.Open()

                ' Query yang sudah diperbaiki - HANYA menampilkan data yang bisa dikembalikan
                ' Status yang ditampilkan:
                ' - 'diterima': Peminjaman sudah dikonfirmasi admin, sedang digunakan, perlu dikembalikan
                ' - 'menunggu dikembalikan': Sudah selesai digunakan, menunggu konfirmasi pengembalian
                ' Status yang TIDAK ditampilkan:
                ' - 'menunggu': Belum dikonfirmasi admin
                ' - 'ditolak': Ditolak admin, tidak perlu dikembalikan
                ' - 'selesai': Sudah selesai dan dikembalikan
                Dim query As String = "
                SELECT 
                    p.peminjaman_id,
                    p.user_id,
                    p.ruangan_id,
                    r.nama_ruangan,
                    p.tanggal,
                    p.waktu_mulai,
                    p.waktu_selesai,
                    p.durasi_peminjaman,
                    p.keterangan,
                    p.status
                FROM peminjaman_ruangan p
                LEFT JOIN ruangan r ON p.ruangan_id = r.ruangan_id
                WHERE p.user_id = @user_id 
                AND p.status IN ('diterima', 'menunggu dikembalikan')
                ORDER BY p.tanggal DESC, p.waktu_mulai ASC"

                Using cmd As New SqlCommand(query, connection)
                    cmd.Parameters.AddWithValue("@user_id", currentUserId)

                    Dim adapter As New SqlDataAdapter(cmd)
                    Dim dataTable As New DataTable()
                    adapter.Fill(dataTable)

                    ' Jika tidak ada data dengan JOIN, coba tanpa JOIN
                    If dataTable.Rows.Count = 0 Then
                        LoadDataPeminjamanAlternative()
                        Return
                    End If

                    ' Set DataSource
                    DataGridView1.DataSource = dataTable

                    ' Set column headers dan visibility
                    If DataGridView1.Columns.Count > 0 Then
                        ' Set headers
                        If DataGridView1.Columns.Contains("peminjaman_id") Then DataGridView1.Columns("peminjaman_id").HeaderText = "ID Peminjaman"
                        If DataGridView1.Columns.Contains("ruangan_id") Then DataGridView1.Columns("ruangan_id").HeaderText = "ID Ruangan"
                        If DataGridView1.Columns.Contains("nama_ruangan") Then DataGridView1.Columns("nama_ruangan").HeaderText = "Nama Ruangan"
                        If DataGridView1.Columns.Contains("tanggal") Then DataGridView1.Columns("tanggal").HeaderText = "Tanggal"
                        If DataGridView1.Columns.Contains("waktu_mulai") Then DataGridView1.Columns("waktu_mulai").HeaderText = "Waktu Mulai"
                        If DataGridView1.Columns.Contains("waktu_selesai") Then DataGridView1.Columns("waktu_selesai").HeaderText = "Waktu Selesai"
                        If DataGridView1.Columns.Contains("durasi_peminjaman") Then DataGridView1.Columns("durasi_peminjaman").HeaderText = "Durasi"
                        If DataGridView1.Columns.Contains("keterangan") Then DataGridView1.Columns("keterangan").HeaderText = "Keterangan"
                        If DataGridView1.Columns.Contains("status") Then DataGridView1.Columns("status").HeaderText = "Status"

                        ' Hide ID columns
                        If DataGridView1.Columns.Contains("peminjaman_id") Then DataGridView1.Columns("peminjaman_id").Visible = False
                        If DataGridView1.Columns.Contains("ruangan_id") Then DataGridView1.Columns("ruangan_id").Visible = False
                        If DataGridView1.Columns.Contains("user_id") Then DataGridView1.Columns("user_id").Visible = False
                    End If

                    ' Show info if no data
                    If dataTable.Rows.Count = 0 Then
                        MessageBox.Show("Tidak ada ruangan yang perlu dikembalikan.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message & vbCrLf & "Stack Trace: " & ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Alternative method tanpa JOIN jika tabel ruangan tidak ada atau ada masalah relasi
    Private Sub LoadDataPeminjamanAlternative()
        Try
            If UserSession.CurrentUser Is Nothing Then
                MessageBox.Show("User session tidak valid. Silakan login kembali.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            Dim currentUserId As Integer = UserSession.CurrentUser.user_id

            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String = "
                SELECT 
                    peminjaman_id,
                    user_id,
                    ruangan_id,
                    tanggal,
                    waktu_mulai,
                    waktu_selesai,
                    durasi_peminjaman,
                    keterangan,
                    status
                FROM peminjaman_ruangan
                WHERE user_id = @user_id 
                AND status IN ('diterima', 'menunggu dikembalikan')
                ORDER BY tanggal DESC, waktu_mulai ASC"

                Using cmd As New SqlCommand(query, connection)
                    cmd.Parameters.AddWithValue("@user_id", currentUserId)

                    Dim adapter As New SqlDataAdapter(cmd)
                    Dim dataTable As New DataTable()
                    adapter.Fill(dataTable)

                    ' Tambahkan kolom nama_ruangan secara manual
                    If Not dataTable.Columns.Contains("nama_ruangan") Then
                        dataTable.Columns.Add("nama_ruangan", GetType(String))
                    End If

                    ' Isi nama ruangan untuk setiap row
                    For Each row As DataRow In dataTable.Rows
                        Dim ruanganId As Integer = Convert.ToInt32(row("ruangan_id"))
                        Dim namaRuangan As String = GetNamaRuangan(ruanganId)
                        row("nama_ruangan") = namaRuangan
                    Next

                    DataGridView1.DataSource = dataTable

                    ' Set column headers
                    If DataGridView1.Columns.Count > 0 Then
                        If DataGridView1.Columns.Contains("peminjaman_id") Then DataGridView1.Columns("peminjaman_id").HeaderText = "ID Peminjaman"
                        If DataGridView1.Columns.Contains("ruangan_id") Then DataGridView1.Columns("ruangan_id").HeaderText = "ID Ruangan"
                        If DataGridView1.Columns.Contains("nama_ruangan") Then DataGridView1.Columns("nama_ruangan").HeaderText = "Nama Ruangan"
                        If DataGridView1.Columns.Contains("tanggal") Then DataGridView1.Columns("tanggal").HeaderText = "Tanggal"
                        If DataGridView1.Columns.Contains("waktu_mulai") Then DataGridView1.Columns("waktu_mulai").HeaderText = "Waktu Mulai"
                        If DataGridView1.Columns.Contains("waktu_selesai") Then DataGridView1.Columns("waktu_selesai").HeaderText = "Waktu Selesai"
                        If DataGridView1.Columns.Contains("durasi_peminjaman") Then DataGridView1.Columns("durasi_peminjaman").HeaderText = "Durasi"
                        If DataGridView1.Columns.Contains("keterangan") Then DataGridView1.Columns("keterangan").HeaderText = "Keterangan"
                        If DataGridView1.Columns.Contains("status") Then DataGridView1.Columns("status").HeaderText = "Status"

                        ' Hide ID columns
                        If DataGridView1.Columns.Contains("peminjaman_id") Then DataGridView1.Columns("peminjaman_id").Visible = False
                        If DataGridView1.Columns.Contains("ruangan_id") Then DataGridView1.Columns("ruangan_id").Visible = False
                        If DataGridView1.Columns.Contains("user_id") Then DataGridView1.Columns("user_id").Visible = False
                    End If

                    ' Show message only if no data found
                    If dataTable.Rows.Count = 0 Then
                        MessageBox.Show("Tidak ada ruangan yang perlu dikembalikan.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Method untuk debugging - hanya digunakan saat diperlukan (tidak otomatis dipanggil)
    Private Sub CheckAllUserData(userId As Integer)
        ' Method ini hanya untuk debugging manual, tidak dipanggil otomatis
        ' Uncomment kode di bawah jika perlu debugging
        '
        'Try
        '    Using connection As New SqlConnection(connectionString)
        '        connection.Open()
        '        Dim query As String = "SELECT peminjaman_id, status, tanggal FROM peminjaman_ruangan WHERE user_id = @user_id"
        '        Using cmd As New SqlCommand(query, connection)
        '            cmd.Parameters.AddWithValue("@user_id", userId)
        '            Dim adapter As New SqlDataAdapter(cmd)
        '            Dim dataTable As New DataTable()
        '            adapter.Fill(dataTable)
        '            Dim debugInfo As String = $"Total data untuk user {userId}: {dataTable.Rows.Count}" & vbCrLf
        '            For Each row As DataRow In dataTable.Rows
        '                debugInfo += $"ID: {row("peminjaman_id")}, Status: {row("status")}, Tanggal: {row("tanggal")}" & vbCrLf
        '            Next
        '            MessageBox.Show(debugInfo, "Debug - All User Data", MessageBoxButtons.OK, MessageBoxIcon.Information)
        '        End Using
        '    End Using
        'Catch ex As Exception
        '    MessageBox.Show("Error checking user data: " & ex.Message, "Debug Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try
    End Sub

    Private Function GetNamaRuangan(ruanganId As Integer) As String
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                ' Coba dulu cek apakah tabel ruangan ada
                Dim checkTableQuery As String = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'ruangan'"
                Using checkCmd As New SqlCommand(checkTableQuery, connection)
                    Dim tableExists As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())
                    If tableExists = 0 Then
                        Return $"Ruangan {ruanganId}" ' Return default name jika tabel tidak ada
                    End If
                End Using

                Dim query As String = "SELECT nama_ruangan FROM ruangan WHERE ruangan_id = @ruangan_id"
                Using cmd As New SqlCommand(query, connection)
                    cmd.Parameters.AddWithValue("@ruangan_id", ruanganId)
                    Dim result = cmd.ExecuteScalar()
                    If result IsNot Nothing Then
                        Return result.ToString()
                    Else
                        Return $"Ruangan {ruanganId}"
                    End If
                End Using
            End Using
        Catch ex As Exception
            Return $"Ruangan {ruanganId}"
        End Try
    End Function

    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 0 Then
            Try
                Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)

                ' Get selected peminjaman_id using safe method
                selectedPeminjamanId = GetSafeIntValue(selectedRow.Cells("peminjaman_id").Value)

                ' Fill form with selected data using safe method
                If DataGridView1.Columns.Contains("nama_ruangan") Then
                    txtnamaruangan.Text = GetSafeStringValue(selectedRow.Cells("nama_ruangan").Value)
                Else
                    ' Jika tidak ada kolom nama_ruangan, ambil dari ruangan_id
                    Dim ruanganId As Integer = GetSafeIntValue(selectedRow.Cells("ruangan_id").Value)
                    txtnamaruangan.Text = GetNamaRuangan(ruanganId)
                End If

                ' Clear waktu pengembalian for new input
                txtwaktu.Clear()
                txtketerangan.Clear()

                ' Enable controls only if we have valid peminjaman_id
                If selectedPeminjamanId > 0 Then
                    txtwaktu.Enabled = True
                    txtketerangan.Enabled = True
                    btnkonfirmasi.Enabled = True
                Else
                    ClearForm()
                End If

            Catch ex As Exception
                MessageBox.Show("Error loading selected data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                ClearForm()
            End Try
        Else
            ClearForm()
        End If
    End Sub

    Private Sub ClearForm()
        selectedPeminjamanId = 0
        txtnamaruangan.Clear()
        txtwaktu.Clear()
        txtketerangan.Clear()
        txtwaktu.Enabled = False
        txtketerangan.Enabled = False
        btnkonfirmasi.Enabled = False
    End Sub

    Private Function ValidateTime(timeString As String) As Boolean
        Dim timeValue As DateTime
        Return DateTime.TryParseExact(timeString, "HH:mm", Nothing, Globalization.DateTimeStyles.None, timeValue)
    End Function

    ' FITUR BARU: Fungsi untuk menghitung denda keterlambatan
    Private Function HitungDenda(waktuSelesai As String, waktuPengembalian As String) As Integer
        Try
            Dim selesai As DateTime = DateTime.ParseExact(waktuSelesai, "HH:mm", Nothing)
            Dim kembali As DateTime = DateTime.ParseExact(waktuPengembalian, "HH:mm", Nothing)

            ' Jika tidak telat, tidak ada denda
            If kembali <= selesai Then
                Return 0
            End If

            ' Hitung selisih dalam menit
            Dim selisihMenit As Integer = CInt((kembali - selesai).TotalMinutes)

            ' Perhitungan denda berdasarkan keterlambatan
            Dim denda As Integer = 0

            ' Setiap 30 menit atau sebagian dari 30 menit = Rp 10.000
            ' Jika kurang dari 30 menit = Rp 5.000
            If selisihMenit <= 30 Then
                denda = 5000 ' Kurang dari atau sama dengan 30 menit = Rp 5.000
            Else
                ' Lebih dari 30 menit: hitung berdasarkan kelipatan 30 menit
                Dim kelipatan30Menit As Integer = Math.Ceiling(selisihMenit / 30.0)
                denda = kelipatan30Menit * 10000
            End If

            Return denda

        Catch ex As Exception
            ' Jika ada error parsing, return 0 (tidak ada denda)
            Return 0
        End Try
    End Function

    ' FITUR BARU: Fungsi untuk menampilkan detail keterlambatan dan denda
    Private Function GetDetailKeterlambatan(waktuSelesai As String, waktuPengembalian As String) As String
        Try
            Dim selesai As DateTime = DateTime.ParseExact(waktuSelesai, "HH:mm", Nothing)
            Dim kembali As DateTime = DateTime.ParseExact(waktuPengembalian, "HH:mm", Nothing)

            If kembali <= selesai Then
                Return "Pengembalian tepat waktu."
            End If

            Dim selisihMenit As Integer = CInt((kembali - selesai).TotalMinutes)
            Dim jam As Integer = selisihMenit \ 60
            Dim menit As Integer = selisihMenit Mod 60

            Dim detailWaktu As String = ""
            If jam > 0 Then
                detailWaktu = $"{jam} jam {menit} menit"
            Else
                detailWaktu = $"{menit} menit"
            End If

            Return $"Telat {detailWaktu} dari waktu seharusnya ({waktuSelesai})."

        Catch ex As Exception
            Return "Tidak dapat menghitung keterlambatan."
        End Try
    End Function

    Private Function GetStatusPengembalian(waktuSelesai As String, waktuPengembalian As String) As String
        Try
            Dim selesai As DateTime = DateTime.ParseExact(waktuSelesai, "HH:mm", Nothing)
            Dim kembali As DateTime = DateTime.ParseExact(waktuPengembalian, "HH:mm", Nothing)

            If kembali <= selesai Then
                Return "Tepat waktu"
            Else
                Return "Telat"
            End If
        Catch
            Return "Tepat waktu" ' Default jika ada error parsing
        End Try
    End Function

    ' FITUR BARU: Fungsi untuk menampilkan peringatan denda
    Private Sub TampilkanPeringatanDenda(waktuSelesai As String, waktuPengembalian As String)
        Try
            Dim denda As Integer = HitungDenda(waktuSelesai, waktuPengembalian)
            Dim detailKeterlambatan As String = GetDetailKeterlambatan(waktuSelesai, waktuPengembalian)

            Dim pesan As String = ""
            Dim judulPesan As String = ""
            Dim iconPesan As MessageBoxIcon

            If denda = 0 Then
                ' Tidak ada denda
                pesan = $"✅ PENGEMBALIAN TEPAT WAKTU" & vbCrLf & vbCrLf &
                       $"Waktu seharusnya selesai: {waktuSelesai}" & vbCrLf &
                       $"Waktu pengembalian: {waktuPengembalian}" & vbCrLf & vbCrLf &
                       $"{detailKeterlambatan}" & vbCrLf & vbCrLf &
                       $"💰 DENDA: Rp 0 (Tidak ada denda)"
                judulPesan = "Pengembalian Berhasil"
                iconPesan = MessageBoxIcon.Information
            Else
                ' Ada denda
                pesan = $"⚠️ PENGEMBALIAN TERLAMBAT" & vbCrLf & vbCrLf &
                       $"Waktu seharusnya selesai: {waktuSelesai}" & vbCrLf &
                       $"Waktu pengembalian: {waktuPengembalian}" & vbCrLf & vbCrLf &
                       $"{detailKeterlambatan}" & vbCrLf & vbCrLf &
                       $"💰 DENDA KETERLAMBATAN: Rp {denda:N0}" & vbCrLf & vbCrLf &
                       $"📋 RINCIAN DENDA:" & vbCrLf &
                       GetRincianDenda(waktuSelesai, waktuPengembalian) & vbCrLf & vbCrLf &
                       $"Silakan lakukan pembayaran denda di bagian administrasi."
                judulPesan = "Peringatan Denda"
                iconPesan = MessageBoxIcon.Warning
            End If

            MessageBox.Show(pesan, judulPesan, MessageBoxButtons.OK, iconPesan)

        Catch ex As Exception
            MessageBox.Show("Error menampilkan peringatan denda: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' FITUR BARU: Fungsi untuk mendapatkan rincian perhitungan denda
    Private Function GetRincianDenda(waktuSelesai As String, waktuPengembalian As String) As String
        Try
            Dim selesai As DateTime = DateTime.ParseExact(waktuSelesai, "HH:mm", Nothing)
            Dim kembali As DateTime = DateTime.ParseExact(waktuPengembalian, "HH:mm", Nothing)

            If kembali <= selesai Then
                Return "- Tidak ada keterlambatan, tidak ada denda"
            End If

            Dim selisihMenit As Integer = CInt((kembali - selesai).TotalMinutes)
            Dim rincian As String = ""

            If selisihMenit <= 30 Then
                rincian = $"- Keterlambatan ≤ 30 menit: Rp 5.000"
            Else
                Dim kelipatan30Menit As Integer = Math.Ceiling(selisihMenit / 30.0)
                rincian = $"- Keterlambatan {selisihMenit} menit" & vbCrLf &
                         $"- Dibulatkan ke {kelipatan30Menit} x 30 menit" & vbCrLf &
                         $"- Denda: {kelipatan30Menit} x Rp 10.000 = Rp {kelipatan30Menit * 10000:N0}"
            End If

            Return rincian

        Catch ex As Exception
            Return "- Error menghitung rincian denda"
        End Try
    End Function

    Private Sub UpdatePengembalian()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                ' Get waktu_selesai from selected row with safe method
                If DataGridView1.SelectedRows.Count = 0 Then
                    MessageBox.Show("Tidak ada data yang dipilih.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Return
                End If

                Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
                Dim waktuSelesai As String = GetSafeStringValue(selectedRow.Cells("waktu_selesai").Value)

                If String.IsNullOrEmpty(waktuSelesai) Then
                    MessageBox.Show("Data waktu selesai tidak valid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                ' Determine status
                Dim statusPengembalian As String = GetStatusPengembalian(waktuSelesai, txtwaktu.Text.Trim())

                ' FITUR BARU: Hitung denda
                Dim denda As Integer = HitungDenda(waktuSelesai, txtwaktu.Text.Trim())

                ' Update query - tambahkan kolom denda
                Dim query As String = "
                    UPDATE peminjaman_ruangan 
                    SET 
                        waktu_pengembalian = @waktu_pengembalian,
                        status_pengembalian = @status_pengembalian,
                        keterangan_pengembalian = @keterangan_pengembalian,
                        denda = @denda,
                        status = 'selesai'
                    WHERE peminjaman_id = @peminjaman_id"

                Using cmd As New SqlCommand(query, connection)
                    cmd.Parameters.AddWithValue("@waktu_pengembalian", txtwaktu.Text.Trim())
                    cmd.Parameters.AddWithValue("@status_pengembalian", statusPengembalian)
                    cmd.Parameters.AddWithValue("@keterangan_pengembalian",
                        If(String.IsNullOrWhiteSpace(txtketerangan.Text), DBNull.Value, txtketerangan.Text.Trim()))
                    cmd.Parameters.AddWithValue("@denda", denda)
                    cmd.Parameters.AddWithValue("@peminjaman_id", selectedPeminjamanId)

                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        ' FITUR BARU: Tampilkan peringatan denda setelah update berhasil
                        TampilkanPeringatanDenda(waktuSelesai, txtwaktu.Text.Trim())

                        ' Reload data and clear form
                        LoadDataPeminjaman()
                        ClearForm()
                    Else
                        MessageBox.Show("Gagal mengupdate data pengembalian.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error updating data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtwaktu_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtwaktu.KeyPress
        ' Allow digits, colon, and control keys
        If Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ":" Or Char.IsControl(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtwaktu_Leave(sender As Object, e As EventArgs) Handles txtwaktu.Leave
        If Not String.IsNullOrWhiteSpace(txtwaktu.Text) Then
            If Not ValidateTime(txtwaktu.Text.Trim()) Then
                MessageBox.Show("Format waktu tidak valid. Gunakan format HH:MM", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtwaktu.Focus()
            Else
                ' FITUR BARU: Preview denda saat user selesai input waktu
                If DataGridView1.SelectedRows.Count > 0 Then
                    Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
                    Dim waktuSelesai As String = GetSafeStringValue(selectedRow.Cells("waktu_selesai").Value)

                    If Not String.IsNullOrEmpty(waktuSelesai) Then
                        TampilkanPreviewDenda(waktuSelesai, txtwaktu.Text.Trim())
                    End If
                End If
            End If
        End If
    End Sub

    ' FITUR BARU: Preview denda sebelum konfirmasi
    Private Sub TampilkanPreviewDenda(waktuSelesai As String, waktuPengembalian As String)
        Try
            Dim denda As Integer = HitungDenda(waktuSelesai, waktuPengembalian)
            Dim detailKeterlambatan As String = GetDetailKeterlambatan(waktuSelesai, waktuPengembalian)

            If denda > 0 Then
                Dim pesan As String = $"⚠️ PREVIEW DENDA" & vbCrLf & vbCrLf &
                                     $"Waktu seharusnya selesai: {waktuSelesai}" & vbCrLf &
                                     $"Waktu pengembalian: {waktuPengembalian}" & vbCrLf & vbCrLf &
                                     $"{detailKeterlambatan}" & vbCrLf & vbCrLf &
                                     $"💰 DENDA: Rp {denda:N0}" & vbCrLf & vbCrLf &
                                     $"Klik 'Konfirmasi' untuk melanjutkan pengembalian."

                MessageBox.Show(pesan, "Preview Denda", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            ' Jika ada error, tidak perlu menampilkan pesan error untuk preview
        End Try
    End Sub

    Private Sub btnkonfirmasi_Click(sender As Object, e As EventArgs) Handles btnkonfirmasi.Click
        ' Validation
        If selectedPeminjamanId = 0 Then
            MessageBox.Show("Silakan pilih data peminjaman terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        If String.IsNullOrWhiteSpace(txtwaktu.Text) Then
            MessageBox.Show("Waktu pengembalian harus diisi.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtwaktu.Focus()
            Return
        End If

        If Not ValidateTime(txtwaktu.Text.Trim()) Then
            MessageBox.Show("Format waktu tidak valid. Gunakan format HH:MM (contoh: 14:30)", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtwaktu.Focus()
            Return
        End If

        ' FITUR BARU: Cek denda sebelum konfirmasi
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
            Dim waktuSelesai As String = GetSafeStringValue(selectedRow.Cells("waktu_selesai").Value)

            If Not String.IsNullOrEmpty(waktuSelesai) Then
                Dim denda As Integer = HitungDenda(waktuSelesai, txtwaktu.Text.Trim())

                Dim pesanKonfirmasi As String = ""
                If denda > 0 Then
                    pesanKonfirmasi = $"⚠️ PERHATIAN!" & vbCrLf & vbCrLf &
                                    $"Pengembalian ini akan dikenakan denda sebesar Rp {denda:N0}" & vbCrLf &
                                    $"karena keterlambatan." & vbCrLf & vbCrLf &
                                    $"Apakah Anda yakin ingin mengkonfirmasi pengembalian ruangan ini?"
                Else
                    pesanKonfirmasi = "Apakah Anda yakin ingin mengkonfirmasi pengembalian ruangan ini?"
                End If

                Dim result As DialogResult = MessageBox.Show(pesanKonfirmasi,
                                                            "Konfirmasi Pengembalian",
                                                            MessageBoxButtons.YesNo,
                                                            MessageBoxIcon.Question)

                If result = DialogResult.Yes Then
                    UpdatePengembalian()
                End If
            End If
        End If
    End Sub

    ' Method untuk testing koneksi database dan data - bisa dipanggil untuk debugging
    Private Sub TestDatabaseAndData()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                MessageBox.Show("Koneksi database berhasil!", "Test Koneksi")

                ' Test user session
                If UserSession.CurrentUser IsNot Nothing Then
                    Dim userId As Integer = UserSession.CurrentUser.user_id
                    MessageBox.Show($"User ID dari session: {userId}", "Test Session")

                    ' Test query dengan berbagai status
                    Dim query As String = "SELECT COUNT(*) FROM peminjaman_ruangan WHERE user_id = @user_id"
                    Using cmd As New SqlCommand(query, connection)
                        cmd.Parameters.AddWithValue("@user_id", userId)
                        Dim totalCount As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                        MessageBox.Show($"Total data untuk user {userId}: {totalCount} record", "Test Data Total")
                    End Using

                    ' Test dengan status tertentu
                    Dim queryStatus As String = "SELECT COUNT(*) FROM peminjaman_ruangan WHERE user_id = @user_id AND status = 'diterima'"
                    Using cmd As New SqlCommand(queryStatus, connection)
                        cmd.Parameters.AddWithValue("@user_id", userId)
                        Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                        MessageBox.Show($"Data dengan status 'diterima' untuk user {userId}: {count} record", "Test Status")
                    End Using
                Else
                    MessageBox.Show("UserSession.CurrentUser adalah NULL!", "Error Session")
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show($"Error testing: {ex.Message}", "Test Error")
        End Try
    End Sub

    ' FITUR BARU: Method untuk testing perhitungan denda (untuk debugging)
    Private Sub TestPerhitunganDenda()
        ' Method ini untuk testing perhitungan denda secara manual
        ' Uncomment untuk testing:
        '
        ' Test case 1: Tidak telat
        'Dim denda1 As Integer = HitungDenda("14:00", "13:45")
        'MessageBox.Show($"Test 1 - Tidak telat: Rp {denda1:N0}", "Test Denda")
        '
        ' Test case 2: Telat 15 menit
        'Dim denda2 As Integer = HitungDenda("14:00", "14:15")
        'MessageBox.Show($"Test 2 - Telat 15 menit: Rp {denda2:N0}", "Test Denda")
        '
        ' Test case 3: Telat 30 menit
        'Dim denda3 As Integer = HitungDenda("14:00", "14:30")
        'MessageBox.Show($"Test 3 - Telat 30 menit: Rp {denda3:N0}", "Test Denda")
        '
        ' Test case 4: Telat 45 menit
        'Dim denda4 As Integer = HitungDenda("14:00", "14:45")
        'MessageBox.Show($"Test 4 - Telat 45 menit: Rp {denda4:N0}", "Test Denda")
        '
        ' Test case 5: Telat 60 menit
        'Dim denda5 As Integer = HitungDenda("14:00", "15:00")
        'MessageBox.Show($"Test 5 - Telat 60 menit: Rp {denda5:N0}", "Test Denda")
    End Sub

End Class
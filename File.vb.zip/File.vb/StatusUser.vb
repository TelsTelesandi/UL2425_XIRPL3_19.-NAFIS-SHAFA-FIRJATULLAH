﻿Imports System.Data.SqlClient
Imports System.IO

Public Class StatusUser
    Private Sub StatusUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set form properties
        Me.Text = "Status Peminjaman"
        Me.WindowState = FormWindowState.Maximized

        ' Initialize ComboBox filter status
        InitializeFilterComboBox()

        ' Load data when form loads
        LoadDataPeminjaman()
    End Sub
    Private Sub InitializeFilterComboBox()
        Try
            ' Clear existing items
            cmbFilterStatus.Items.Clear()

            ' Add filter options
            cmbFilterStatus.Items.Add("Semua")
            cmbFilterStatus.Items.Add("Menunggu")
            cmbFilterStatus.Items.Add("Disetujui")
            cmbFilterStatus.Items.Add("Ditolak")
            cmbFilterStatus.Items.Add("Selesai")

            ' Set default selection
            cmbFilterStatus.SelectedIndex = 0 ' "Semua" as default

            ' Set ComboBox properties
            cmbFilterStatus.DropDownStyle = ComboBoxStyle.DropDownList ' Prevent manual editing

        Catch ex As Exception
            MessageBox.Show("Error initializing filter: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub FilterByStatus(status As String)
        Try
            Using connection As SqlConnection = GetConnection()
                connection.Open()

                Dim query As String = "SELECT 
                p.peminjaman_id,
                p.user_id,
                p.ruangan_id,
                p.tanggal,
                p.waktu_mulai,
                p.durasi_peminjaman,
                p.waktu_selesai,
                p.status,
                p.keterangan,
                p.waktu_pengembalian,
                p.status_pengembalian,
                p.keterangan_pengembalian,
                r.nama_ruangan,
                u.nama_lengkap
            FROM peminjaman_ruangan p
            INNER JOIN ruangan r ON p.ruangan_id = r.ruangan_id
            INNER JOIN users u ON p.user_id = u.user_id
            WHERE p.user_id = @user_id"

                If Not String.IsNullOrEmpty(status) AndAlso status <> "Semua" Then
                    query &= " AND p.status = @status"
                End If

                query &= " ORDER BY p.tanggal DESC, p.waktu_mulai DESC"

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@user_id", UserSession.CurrentUser.user_id)
                    If Not String.IsNullOrEmpty(status) AndAlso status <> "Semua" Then
                        command.Parameters.AddWithValue("@status", status)
                    End If

                    Using adapter As New SqlDataAdapter(command)
                        Dim dataTable As New DataTable()
                        adapter.Fill(dataTable)
                        DataGridView1.DataSource = dataTable

                        ' Format DataGridView after filtering
                        FormatDataGridView()

                        ' Update status label with filter info
                        UpdateStatusLabelWithFilter(dataTable.Rows.Count, status)
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error filtering data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub UpdateStatusLabelWithFilter(recordCount As Integer, filterStatus As String)
        Try
            If Me.Controls.Find("lblStatus", True).Length > 0 Then
                Dim lblStatus As Label = CType(Me.Controls.Find("lblStatus", True)(0), Label)

                If String.IsNullOrEmpty(filterStatus) OrElse filterStatus = "Semua" Then
                    lblStatus.Text = $"Total peminjaman Anda: {recordCount} record"
                Else
                    lblStatus.Text = $"Peminjaman dengan status '{filterStatus}': {recordCount} record"
                End If
            End If
        Catch ex As Exception
            ' Handle error silently or log it
            Console.WriteLine("Error updating status label: " & ex.Message)
        End Try
    End Sub

    Private Sub LoadDataPeminjaman()
        Try
            ' Check if user is logged in
            If Not UserSession.CurrentUser.isLoggedIn Then
                MessageBox.Show("Silakan login terlebih dahulu!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Using connection As SqlConnection = GetConnection()
                connection.Open()

                ' Query untuk mengambil data peminjaman sesuai user_id yang login
                Dim query As String = "SELECT 
                    p.peminjaman_id,
                    p.user_id,
                    p.ruangan_id,
                    p.tanggal,
                    p.waktu_mulai,
                    p.durasi_peminjaman,
                    p.waktu_selesai,
                    p.status,
                    p.keterangan,
                    p.waktu_pengembalian,
                    p.status_pengembalian,
                    p.keterangan_pengembalian,
                    r.nama_ruangan,
                    u.nama_lengkap
                FROM peminjaman_ruangan p
                INNER JOIN ruangan r ON p.ruangan_id = r.ruangan_id
                INNER JOIN users u ON p.user_id = u.user_id
                WHERE p.user_id = @user_id
                ORDER BY p.tanggal DESC, p.waktu_mulai DESC"

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@user_id", UserSession.CurrentUser.user_id)

                    Using adapter As New SqlDataAdapter(command)
                        Dim dataTable As New DataTable()
                        adapter.Fill(dataTable)

                        ' Bind data to DataGridView
                        DataGridView1.DataSource = dataTable

                        ' Format DataGridView
                        FormatDataGridView()

                        ' Update status label
                        UpdateStatusLabel(dataTable.Rows.Count)
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub FormatDataGridView()
        With DataGridView1
            ' Set general properties
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .MultiSelect = False
            .ReadOnly = True
            .AllowUserToAddRows = False
            .AllowUserToDeleteRows = False
            .RowHeadersVisible = False

            ' Set column headers and formatting
            If .Columns.Count > 0 Then
                .Columns("peminjaman_id").HeaderText = "ID Peminjaman"
                .Columns("peminjaman_id").Width = 100

                .Columns("user_id").HeaderText = "User ID"
                .Columns("user_id").Width = 80

                .Columns("ruangan_id").HeaderText = "ID Ruangan"
                .Columns("ruangan_id").Width = 100

                .Columns("tanggal").HeaderText = "Tanggal"
                .Columns("tanggal").Width = 100
                .Columns("tanggal").DefaultCellStyle.Format = "dd/MM/yyyy"

                .Columns("waktu_mulai").HeaderText = "Waktu Mulai"
                .Columns("waktu_mulai").Width = 100

                .Columns("durasi_peminjaman").HeaderText = "Durasi"
                .Columns("durasi_peminjaman").Width = 80

                .Columns("waktu_selesai").HeaderText = "Waktu Selesai"
                .Columns("waktu_selesai").Width = 100

                .Columns("status").HeaderText = "Status"
                .Columns("status").Width = 100

                .Columns("keterangan").HeaderText = "Keterangan"
                .Columns("keterangan").Width = 150

                .Columns("waktu_pengembalian").HeaderText = "Waktu Pengembalian"
                .Columns("waktu_pengembalian").Width = 130

                .Columns("status_pengembalian").HeaderText = "Status Pengembalian"
                .Columns("status_pengembalian").Width = 130

                .Columns("keterangan_pengembalian").HeaderText = "Keterangan Pengembalian"
                .Columns("keterangan_pengembalian").Width = 180

                .Columns("nama_ruangan").HeaderText = "Nama Ruangan"
                .Columns("nama_ruangan").Width = 150

                .Columns("nama_lengkap").HeaderText = "Nama Peminjam"
                .Columns("nama_lengkap").Width = 150
            End If

            ' Set alternating row colors
            .AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray
            .DefaultCellStyle.BackColor = Color.White
            .DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise
            .DefaultCellStyle.SelectionForeColor = Color.White
        End With
    End Sub

    Private Sub UpdateStatusLabel(recordCount As Integer)
        ' Update label to show record count
        If Me.Controls.Find("lblStatus", True).Length > 0 Then
            Dim lblStatus As Label = CType(Me.Controls.Find("lblStatus", True)(0), Label)
            lblStatus.Text = $"Total peminjaman Anda: {recordCount} record"
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        LoadDataPeminjaman()
    End Sub

    Private Sub btnKembali_Click(sender As Object, e As EventArgs) Handles btnkembali.Click
        Me.Close()
        DashboardUser.Show()
    End Sub

    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        ' Format status cells with colors
        If DataGridView1.Columns(e.ColumnIndex).Name = "status" Then
            If e.Value IsNot Nothing Then
                Select Case e.Value.ToString().ToLower()
                    Case "diterima", "selesai"
                        e.CellStyle.BackColor = Color.LightGreen
                        e.CellStyle.ForeColor = Color.DarkGreen
                    Case "ditolak"
                        e.CellStyle.BackColor = Color.LightCoral
                        e.CellStyle.ForeColor = Color.DarkRed
                    Case "menunggu"
                        e.CellStyle.BackColor = Color.LightYellow
                        e.CellStyle.ForeColor = Color.DarkOrange
                End Select
            End If
        End If
    End Sub

    ' Method untuk refresh data dari form lain
    Public Sub RefreshData()
        LoadDataPeminjaman()
    End Sub



    ' Event handler untuk combo box filter status (jika ada)
    Private Sub cmbFilterStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFilterStatus.SelectedIndexChanged
        Try
            If cmbFilterStatus.SelectedItem IsNot Nothing Then
                Dim selectedStatus As String = cmbFilterStatus.SelectedItem.ToString()
                FilterByStatus(selectedStatus)
            End If
        Catch ex As Exception
            MessageBox.Show("Error applying filter: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnprint_Click(sender As Object, e As EventArgs) Handles btnprint.Click
        Try
            ' Check if user is logged in
            If Not UserSession.CurrentUser.isLoggedIn Then
                MessageBox.Show("Silakan login terlebih dahulu!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Check if there are accepted bookings to print
            If Not HasAcceptedBookings() Then
                MessageBox.Show("Tidak ada peminjaman yang diterima untuk dicetak!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Show print preview dialog
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()

        Catch ex As Exception
            MessageBox.Show("Error saat mempersiapkan dokumen cetak: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Function HasAcceptedBookings() As Boolean
        Try
            Using connection As SqlConnection = GetConnection()
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM peminjaman_ruangan WHERE user_id = @user_id AND status = 'diterima'"
                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@user_id", UserSession.CurrentUser.user_id)
                    Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub btnrefresh_Click_1(sender As Object, e As EventArgs) Handles btnrefresh.Click
        ' Reset filter to "Semua"
        cmbFilterStatus.SelectedIndex = 0
        LoadDataPeminjaman()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Try
            ' Set fonts and brushes
            Dim titleFont As New Font("Arial", 16, FontStyle.Bold)
            Dim headerFont As New Font("Arial", 12, FontStyle.Bold)
            Dim normalFont As New Font("Arial", 10, FontStyle.Regular)
            Dim smallFont As New Font("Arial", 8, FontStyle.Regular)
            Dim blackBrush As New SolidBrush(Color.Black)

            ' Set initial position
            Dim yPosition As Integer = 50
            Dim leftMargin As Integer = 50
            Dim pageWidth As Integer = e.PageBounds.Width - 100

            ' Get accepted bookings data
            Dim bookingsData As DataTable = GetAcceptedBookingsData()

            If bookingsData.Rows.Count = 0 Then
                e.Graphics.DrawString("Tidak ada data peminjaman yang diterima", normalFont, blackBrush, leftMargin, yPosition)
                Return
            End If

            ' Print each accepted booking
            For Each row As DataRow In bookingsData.Rows
                ' Check if we need a new page
                If yPosition > e.PageBounds.Height - 300 Then
                    e.HasMorePages = True
                    Return
                End If

                ' Draw room image (if exists)
                Dim imagePath As String = Path.Combine(Application.StartupPath, row("gambar_path").ToString())
                If File.Exists(imagePath) Then
                    Try
                        Using img As Image = Image.FromFile(imagePath)
                            ' Calculate image size (maintain aspect ratio)
                            Dim imgWidth As Integer = 200
                            Dim imgHeight As Integer = CInt((img.Height * imgWidth) / img.Width)
                            If imgHeight > 150 Then
                                imgHeight = 150
                                imgWidth = CInt((img.Width * imgHeight) / img.Height)
                            End If

                            ' Center the image
                            Dim imgX As Integer = (pageWidth - imgWidth) \ 2 + leftMargin
                            e.Graphics.DrawImage(img, imgX, yPosition, imgWidth, imgHeight)
                            yPosition += imgHeight + 20
                        End Using
                    Catch imgEx As Exception
                        ' If image fails to load, just continue without it
                        Console.WriteLine("Failed to load image: " & imgEx.Message)
                    End Try
                End If

                ' Draw title
                Dim title As String = "STRUK PEMINJAMAN RUANGAN"
                Dim titleSize As SizeF = e.Graphics.MeasureString(title, titleFont)
                Dim titleX As Integer = (pageWidth - titleSize.Width) \ 2 + leftMargin
                e.Graphics.DrawString(title, titleFont, blackBrush, titleX, yPosition)
                yPosition += 50

                ' Draw room name
                Dim roomName As String = "(" & row("nama_ruangan").ToString() & ")"
                Dim roomNameSize As SizeF = e.Graphics.MeasureString(roomName, headerFont)
                Dim roomNameX As Integer = (pageWidth - roomNameSize.Width) \ 2 + leftMargin
                e.Graphics.DrawString(roomName, headerFont, blackBrush, roomNameX, yPosition)
                yPosition += 40

                ' Draw location and capacity on same line
                Dim locationCapacity As String = "(" & row("lokasi").ToString() & ")" & New String(" "c, 20) & "(" & row("kapasitas").ToString() & ")"
                Dim locCapSize As SizeF = e.Graphics.MeasureString(locationCapacity, normalFont)
                Dim locCapX As Integer = (pageWidth - locCapSize.Width) \ 2 + leftMargin
                e.Graphics.DrawString(locationCapacity, normalFont, blackBrush, locCapX, yPosition)
                yPosition += 40

                ' Draw booking details
                yPosition += 10
                e.Graphics.DrawString("Dipinjam oleh : " & row("nama_lengkap").ToString(), normalFont, blackBrush, leftMargin, yPosition)
                yPosition += 25

                ' Format date
                Dim bookingDate As DateTime = Convert.ToDateTime(row("tanggal"))
                e.Graphics.DrawString("Hari/Tanggal : " & bookingDate.ToString("dd/MM/yyyy"), normalFont, blackBrush, leftMargin, yPosition)
                yPosition += 25

                ' Format time
                Dim waktuMulai As String = row("waktu_mulai").ToString()
                Dim waktuSelesai As String = row("waktu_selesai").ToString()
                e.Graphics.DrawString("Waktu Pemakaian : (" & waktuMulai & " sampai " & waktuSelesai & ")", normalFont, blackBrush, leftMargin, yPosition)
                yPosition += 25

                ' Draw keterangan
                Dim keterangan As String = If(String.IsNullOrEmpty(row("keterangan").ToString()), "-", row("keterangan").ToString())
                e.Graphics.DrawString("Keterangan : " & keterangan, normalFont, blackBrush, leftMargin, yPosition)
                yPosition += 50

                ' Draw footer message
                yPosition += 20
                Dim footerMsg As String = "Serahkan bukti peminjaman ke penjaga ruangan jika di perlukan"
                Dim footerSize As SizeF = e.Graphics.MeasureString(footerMsg, smallFont)
                Dim footerX As Integer = (pageWidth - footerSize.Width) \ 2 + leftMargin
                e.Graphics.DrawString(footerMsg, smallFont, blackBrush, footerX, yPosition)
                yPosition += 40

                ' Draw separator line
                e.Graphics.DrawLine(Pens.Black, leftMargin, yPosition, pageWidth + leftMargin, yPosition)
                yPosition += 40
            Next

            ' Print timestamp
            yPosition += 20
            Dim printTime As String = "Dicetak pada: " & DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")
            e.Graphics.DrawString(printTime, smallFont, blackBrush, leftMargin, yPosition)

            ' Dispose resources
            titleFont.Dispose()
            headerFont.Dispose()
            normalFont.Dispose()
            smallFont.Dispose()
            blackBrush.Dispose()

        Catch ex As Exception
            MessageBox.Show("Error saat mencetak dokumen: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Function GetAcceptedBookingsData() As DataTable
        Dim dataTable As New DataTable()

        Try
            Using connection As SqlConnection = GetConnection()
                connection.Open()

                Dim query As String = "SELECT 
                p.peminjaman_id,
                p.user_id,
                p.ruangan_id,
                p.tanggal,
                p.waktu_mulai,
                p.durasi_peminjaman,
                p.waktu_selesai,
                p.status,
                p.keterangan,
                r.nama_ruangan,
                r.lokasi,
                r.kapasitas,
                r.gambar_path,
                u.nama_lengkap
            FROM peminjaman_ruangan p
            INNER JOIN ruangan r ON p.ruangan_id = r.ruangan_id
            INNER JOIN users u ON p.user_id = u.user_id
            WHERE p.user_id = @user_id AND p.status = 'diterima'
            ORDER BY p.tanggal DESC, p.waktu_mulai DESC"

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@user_id", UserSession.CurrentUser.user_id)

                    Using adapter As New SqlDataAdapter(command)
                        adapter.Fill(dataTable)
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error mengambil data peminjaman: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Return dataTable
    End Function
End Class
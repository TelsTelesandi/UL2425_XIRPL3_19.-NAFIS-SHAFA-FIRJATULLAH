﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Approve
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.dgvpeminjaman = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnterima = New System.Windows.Forms.Button()
        Me.btntolak = New System.Windows.Forms.Button()
        CType(Me.dgvpeminjaman, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(989, 194)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(106, 26)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "Kembali"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'dgvpeminjaman
        '
        Me.dgvpeminjaman.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvpeminjaman.Location = New System.Drawing.Point(47, 226)
        Me.dgvpeminjaman.Name = "dgvpeminjaman"
        Me.dgvpeminjaman.Size = New System.Drawing.Size(1048, 280)
        Me.dgvpeminjaman.TabIndex = 22
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(44, 139)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(329, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Berikut daftar peminjaman yang menunggu untuk diberikan Approval"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Akira Expanded", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(40, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(820, 39)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Form Approval Peminjaman"
        '
        'btnterima
        '
        Me.btnterima.Location = New System.Drawing.Point(47, 526)
        Me.btnterima.Name = "btnterima"
        Me.btnterima.Size = New System.Drawing.Size(106, 26)
        Me.btnterima.TabIndex = 24
        Me.btnterima.Text = "Terima"
        Me.btnterima.UseVisualStyleBackColor = True
        '
        'btntolak
        '
        Me.btntolak.Location = New System.Drawing.Point(159, 526)
        Me.btntolak.Name = "btntolak"
        Me.btntolak.Size = New System.Drawing.Size(106, 26)
        Me.btntolak.TabIndex = 25
        Me.btntolak.Text = "Tolak"
        Me.btntolak.UseVisualStyleBackColor = True
        '
        'Approve
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkCyan
        Me.ClientSize = New System.Drawing.Size(1130, 654)
        Me.Controls.Add(Me.btntolak)
        Me.Controls.Add(Me.btnterima)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.dgvpeminjaman)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Name = "Approve"
        Me.Text = "Approve"
        CType(Me.dgvpeminjaman, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents dgvpeminjaman As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnterima As Button
    Friend WithEvents btntolak As Button
End Class

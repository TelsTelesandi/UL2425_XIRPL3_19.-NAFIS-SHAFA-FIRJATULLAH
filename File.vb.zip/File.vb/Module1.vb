﻿Imports System.Data.SqlClient

Module Module1
    ' String koneksi database
    Public ConnectionString As String = "Data Source=LAPTOP-OIM6A7PT\SQLEXPRESS;Initial Catalog=PJR_NAFIS;Integrated Security=True"
    Public namaUser As String

    Public Function GetConnection() As SqlConnection
        Dim connection As New SqlConnection(ConnectionString)
        Return connection
    End Function
End Module

Public Module UserSession
    Public Class LoggedUser
        Public Property user_id As Integer
        Public Property username As String
        Public Property role As String
        Public Property jenis_pengguna As String
        Public Property nama_lengkap As String
        Public Property isLoggedIn As Boolean
    End Class

    Public CurrentUser As New LoggedUser()

    Public Sub ClearSession()
        CurrentUser.user_id = 0
        CurrentUser.username = ""
        CurrentUser.role = ""
        CurrentUser.jenis_pengguna = ""
        CurrentUser.nama_lengkap = ""
        CurrentUser.isLoggedIn = False
    End Sub
End Module

